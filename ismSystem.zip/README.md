# ISM Robosoft reparado

Versión frontend demo reparada sobre la base rota enviada por el usuario.

Incluye:
- Login demo por rol
- Panel Administrador / Docente / Alumno
- Inventario con solicitud de préstamo y gestión de préstamos
- Notificación a administrador al crear solicitud
- Biblioteca digital con alta de recursos desde modal
- Campus Docente con alta de cursos y contenidos
- Campus Alumno con visualización tipo LMS de lecciones, tareas y evaluativos
- Filtros y gráficos por módulo

Accesos demo:
- admin / admin123
- docente / docente123
- alumno / alumno123
