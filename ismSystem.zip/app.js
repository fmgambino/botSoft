const ICONS = {
  dashboard: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`,
  users: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
  roles: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 2 7 4v6c0 5-3.5 9.74-7 10-3.5-.26-7-5-7-10V6l7-4Z"/><path d="M9 12l2 2 4-4"/></svg>`,
  teams: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="8" cy="8" r="3"/><circle cx="16" cy="8" r="3"/><path d="M2 20a6 6 0 0 1 12 0"/><path d="M10 20a6 6 0 0 1 12 0"/></svg>`,
  inventory: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>`,
  campus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 8l10-5 10 5-10 5-10-5Z"/><path d="M6 10.6v4.4c0 1.7 2.7 3 6 3s6-1.3 6-3v-4.4"/></svg>`,
  library: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>`,
  bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 17h5l-1.4-1.4A2 2 0 0 1 18 14.2V11a6 6 0 1 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5"/><path d="M9 17a3 3 0 0 0 6 0"/></svg>`,
  profile: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M6 20a6 6 0 0 1 12 0"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 15.5A3.5 3.5 0 1 0 12 8.5a3.5 3.5 0 0 0 0 7Z"/><path d="M19.4 15a1.7 1.7 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.82-.33 1.7 1.7 0 0 0-1 1.54V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1-1.54 1.7 1.7 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.54-1H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.54-1 1.7 1.7 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 8.95 4.6a1.7 1.7 0 0 0 1-1.54V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.54 1.7 1.7 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9c.2.48.72.8 1.25.8H21a2 2 0 1 1 0 4h-.35c-.53 0-1.05.32-1.25.8Z"/></svg>`,
  logout: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/></svg>`,
  fullscreen: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>`,
  eye: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>`,
  edit: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/></svg>`,
  delete: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg>`,
  import: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>`,
  export: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21V9"/><path d="m17 14-5-5-5 5"/><path d="M5 3h14"/></svg>`,
  chart: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 14v3"/><path d="M12 10v7"/><path d="M17 6v11"/></svg>`,
  sun: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>`,
  moon: `<svg class="small-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3a7 7 0 1 0 9 9 9 9 0 1 1-9-9z"/></svg>`
};

const state = {
  role: localStorage.getItem('ism-role') || 'admin',
  theme: localStorage.getItem('ism-theme') || 'dark',
  view: null,
  notificationsOpen: false,
  selectedCourseId: null,
  selectedCourseItemId: null,
  selectedChartModule: null,
  chart: null
};

const DB = {
  admin: { name: 'Administrador General', email: 'admin@ism.edu.ar' },
  docente: { name: 'María López', email: 'mlopez@ism.edu.ar', subject: 'Robótica aplicada' },
  alumno: { name: 'Thiago Benjamín Luna', email: 'thiago.luna@ism.edu.ar', team: 'Equipo Rover A · 6°C' }
};

const demo = {
  users: [
    { name: 'Fernando Gambino', role: 'Administrador', email: 'fgambino@ism.edu.ar', whatsapp: '+54 9 11 5555 1111', dni: '30111222', status: 'Activo' },
    { name: 'María López', role: 'Docente', email: 'mlopez@ism.edu.ar', whatsapp: '+54 9 11 4444 2222', dni: '28999888', status: 'Activo' },
    { name: 'Lucas Méndez', role: 'Docente', email: 'lmendez@ism.edu.ar', whatsapp: '+54 9 11 4000 1000', dni: '29666777', status: 'Activo' },
    { name: 'Thiago Benjamín Luna', role: 'Alumno', email: 'thiago.luna@ism.edu.ar', whatsapp: '+54 9 11 3333 1111', dni: '49442589', status: 'Pendiente' },
    { name: 'Tomás Cáceres', role: 'Alumno', email: 'tcaceres@ism.edu.ar', whatsapp: '+54 9 11 2222 7777', dni: '48205464', status: 'Activo' }
  ],
  teams: [
    { name: 'Equipo Rover A', docentes: ['María López', 'Lucas Méndez'], cursos: ['6°C', '6°A'], divisiones: ['C', 'A'], alumnos: 12, status: 'Activo' },
    { name: 'Maker Mix', docentes: ['María López'], cursos: ['5°B', '6°C'], divisiones: ['B', 'C'], alumnos: 8, status: 'Activo' }
  ],
  inventory: [
    { code: 'AR000322', item: 'Kit Prog. de las Cosas', type: 'Equipo', serial: 'KIT-ISM-322', barcode: 'ISM-AR000322', status: 'Disponible', condition: 'Usado, completo', assigned: 'Depósito', teacher: '-', requested: '-', returned: '-', location: 'Armario A1' },
    { code: 'AR000311', item: 'Kit Prog. de las Cosas', type: 'Equipo', serial: 'KIT-ISM-311', barcode: 'ISM-AR000311', status: 'Prestado', condition: 'Usado, dañado, falta piezas', assigned: 'Equipo Rover A', teacher: 'María López', requested: '2026-04-14 10:00', returned: '-', location: 'Taller revisión' },
    { code: 'AR000362', item: 'Kit Prog. de las Cosas', type: 'Equipo', serial: 'Sin serie', barcode: 'ISM-BAR-000362', status: 'Disponible', condition: 'Nuevo', assigned: 'Depósito', teacher: '-', requested: '-', returned: '-', location: 'Depósito' },
    { code: 'SEN-0021', item: 'Sensor ultrasónico', type: 'Insumo', serial: 'Sin serie', barcode: 'ISM-BAR-0021', status: 'Disponible', condition: 'Nuevo', assigned: 'Depósito', teacher: '-', requested: '-', returned: '-', location: 'Gaveta S2' },
    { code: 'ROB-0098', item: 'Placa Arduino UNO', type: 'Equipo', serial: 'ARD-U-0098', barcode: 'ISM-ROB-0098', status: 'En mantenimiento', condition: 'Revisión', assigned: 'Laboratorio', teacher: 'Lucas Méndez', requested: '2026-04-10 09:30', returned: '2026-04-12 13:20', location: 'Mesa técnica' }
  ],
  loans: [
    { id: 1, role: 'docente', requester: 'María López', team: 'Equipo Rover A / 6°C', date: '2026-04-16', from: '08:00', to: '11:30', items: ['AR000322', 'SEN-0021'], notes: 'Clase de sensores', status: 'Pendiente' },
    { id: 2, role: 'admin', requester: 'Lucas Méndez', team: 'Maker Mix / 5°B', date: '2026-04-12', from: '09:00', to: '10:30', items: ['ROB-0098'], notes: 'Taller de mantenimiento', status: 'Aprobado' }
  ],
  notifications: [
    { id: 1, title: 'Préstamo vencido', body: 'El kit AR000311 debía devolverse hoy a las 16:00.', unread: true, target: 'admin', type: 'warning' },
    { id: 2, title: 'Ingreso de inventario', body: 'Se registraron 6 sensores ultrasónicos nuevos.', unread: false, target: 'all', type: 'info' },
    { id: 3, title: 'Módulo actualizado', body: 'Electrónica aplicada ya tiene evaluativo publicado.', unread: true, target: 'all', type: 'info' }
  ],
  resources: [
    { id: 1, title: 'Manual Arduino ISM', category: 'Electrónica', type: 'PDF', source: 'Archivo PDF', url: '#', description: 'Guía base para Arduino.' },
    { id: 2, title: 'Guía Diseño 3D', category: 'Fabricación digital', type: 'PDF', source: 'Archivo PDF', url: '#', description: 'Modelado e impresión 3D.' },
    { id: 3, title: 'Seguridad del laboratorio', category: 'Normas', type: 'Video', source: 'YouTube', url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', description: 'Protocolos del laboratorio.' }
  ],
  courses: [
    {
      id: 1,
      title: 'Electrónica aplicada',
      teacher: 'María López',
      team: 'Equipo Rover A · 6°C',
      visibility: 'Público',
      code: 'ISM-ELEC-401',
      accessKey: 'robotica2026',
      progress: 68,
      status: 'Publicado',
      description: 'Circuitos, sensores y programación aplicada al laboratorio.',
      enrolled: ['Thiago Benjamín Luna'],
      items: [
        { id: 'm1', kind: 'lesson', module: 'Módulo I — Bienvenida', title: 'Clase 01 – Bienvenida & Mentalidad del laboratorio', date: '12/03/26', duration: '76 minutos', body: 'En esta primera clase damos inicio al curso y revisamos normas, objetivos y metodología de trabajo.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', attachments: [{ name: 'Clase 01 - Bienvenida.pdf', type: 'pdf', size: '265KB' }] },
        { id: 't1', kind: 'task', module: 'Módulo I — Bienvenida', title: 'Tarea 01 – Calendario Económico', duration: '7 días', points: 10, passing: 7, retries: 3, instructions: ['Ingresa a una plataforma como Investing.com.', 'Identifica dos noticias de alto impacto.', 'Explicá qué evento es y su posible impacto.'], deliverables: ['Capturas de calendario económico', 'Noticia analizada', 'Breve conclusión como trader/analista.'] },
        { id: 'q1', kind: 'quiz', module: 'Módulo I — Bienvenida', title: 'Evaluativo 01 – Herramientas del laboratorio', time: '20:00', question: '¿Cuál es el objetivo principal del calendario económico?', options: ['Analizar gráficos técnicos', 'Identificar eventos que impactan el mercado', 'Ejecutar operaciones automáticamente', 'Crear estrategias de trading'], correct: 1, feedback: 'El calendario económico muestra eventos clave que pueden generar movimientos, ayudando a anticiparse.' },
        { id: 'm2', kind: 'lesson', module: 'Módulo II — Sensores', title: 'Clase 02 – Sensores ultrasónicos', date: '19/03/26', duration: '96 minutos', body: 'Introducción al sensor HC-SR04 y prácticas de medición de distancia.', video: 'https://www.youtube.com/embed/aqz-KE-bpKQ', attachments: [{ name: 'HC-SR04.pdf', type: 'pdf', size: '132KB' }] }
      ]
    },
    {
      id: 2,
      title: 'Diseño e impresión 3D',
      teacher: 'Lucas Méndez',
      team: 'Visible para todos',
      visibility: 'Público',
      code: 'ISM-3D-205',
      accessKey: 'makerlab',
      progress: 0,
      status: 'Publicado',
      description: 'Diseño CAD básico y preparación de impresión.',
      enrolled: ['Thiago Benjamín Luna'],
      items: [
        { id: 'm3', kind: 'lesson', module: 'Módulo I — Diseño', title: 'Clase 01 – Introducción al modelado', date: '02/04/26', duration: '54 minutos', body: 'Conocé la interfaz y el flujo básico de diseño.', video: 'https://www.youtube.com/embed/dQw4w9WgXcQ', attachments: [] }
      ]
    }
  ]
};

function getUnreadCount() {
  return demo.notifications.filter(n => n.unread && (n.target === 'all' || n.target === state.role)).length;
}
function roleLabel() {
  return state.role === 'admin' ? 'Administrador' : state.role === 'docente' ? 'Docente' : 'Alumno';
}
function roleViews() {
  const common = ['dashboard', 'library', 'notifications', 'profile'];
  if (state.role === 'admin') return ['dashboard', 'users', 'roles', 'teams', 'inventory', 'loanManagement', 'campusTeacher', 'library', 'notifications', 'profile', 'settings'];
  if (state.role === 'docente') return ['dashboard', 'teams', 'inventory', 'loanManagement', 'campusTeacher', 'library', 'notifications', 'profile'];
  return ['dashboard', 'campusStudent', 'library', 'notifications', 'profile'];
}
function viewTitle(view) {
  return {
    dashboard: state.role === 'alumno' ? 'Dashboard alumno' : 'Dashboard',
    users: 'Usuarios', roles: 'Roles y permisos', teams: 'Equipos', inventory: 'Inventario', loanManagement: 'Gestión de préstamos', campusTeacher: 'Campus docente', campusStudent: 'Campus alumno', library: 'Biblioteca digital', notifications: 'Notificaciones', profile: 'Mi perfil', settings: 'Configuraciones'
  }[view] || 'Panel';
}
function viewDesc(view) {
  return {
    dashboard: state.role === 'alumno' ? 'Cursos inscriptos, tareas pendientes y actividad reciente' : 'Gestión administrativa del Laboratorio de Robótica',
    inventory: state.role === 'docente' ? 'Solicitud de préstamo, estado de insumos y seguimiento de devoluciones' : 'Trazabilidad por serie o código de barras, préstamos y devoluciones',
    campusTeacher: 'Alta y gestión de cursos, módulos, lecciones, tareas y evaluativos',
    campusStudent: 'Tus cursos, materiales, tareas y evaluativos',
    library: 'Recursos para tus clases y laboratorios',
    loanManagement: 'Solicitudes, aprobaciones, devoluciones y auditoría de préstamos',
    notifications: 'Avisos masivos, individuales y por equipo',
    profile: 'Visualización y edición de datos del usuario'
  }[view] || 'Panel de gestión';
}

function iconButton(id, icon, title='') {
  return `<button class="btn btn-secondary btn-icon" id="${id}" title="${title}">${icon}</button>`;
}

function themeToggleMarkup() {
  return `<button class="icon-toggle" id="themeToggle" aria-label="Cambiar tema">
    <span class="toggle-track"><span class="toggle-thumb"></span></span>
    <span class="toggle-icons">${ICONS.sun}${ICONS.moon}</span>
  </button>`;
}

function navItem(view, label, icon) {
  const active = state.view === view ? 'active' : '';
  return `<a class="nav-link ${active}" href="#" data-view="${view}">${icon}${label}</a>`;
}

function appShell() {
  if (!state.view) state.view = roleViews()[0];
  document.body.classList.toggle('light', state.theme === 'light');
  const user = DB[state.role];
  document.getElementById('app').innerHTML = `
    <aside class="sidebar">
      <div class="sidebar-brand" id="brandToggle">
        <img src="assets/img/logo-Coordinacion-Robotica.png" alt="ISM" />
        <div>
          <h3>Instituto San Miguel</h3>
          <p>Laboratorio de Robótica</p>
        </div>
      </div>
      <nav class="sidebar-menu">
        ${roleViews().map(v => navItem(v, navLabel(v), navIcon(v))).join('')}
        <a class="nav-link" href="#" id="sidebarLogout">${ICONS.logout}Cerrar sesión</a>
      </nav>
      <div class="sidebar-footer">ISM ROBOSOFT© 2026</div>
    </aside>
    <main class="main">
      <header class="header">
        <div>
          <h1>${viewTitle(state.view)}</h1>
          <p>${viewDesc(state.view)}</p>
        </div>
        <div class="header-actions">
          ${themeToggleMarkup()}
          ${iconButton('fullscreenBtn', ICONS.fullscreen, 'Pantalla completa')}
          <div class="icon-wrap notifications-wrapper">
            ${iconButton('bellBtn', ICONS.bell, 'Notificaciones')}
            ${getUnreadCount() ? `<span class="badge-dot">${getUnreadCount()}</span>` : ''}
            <div class="notification-panel notifications-preview ${state.notificationsOpen ? 'open' : ''}" id="notificationPanel">
              ${(demo.notifications.filter(n => n.target === 'all' || n.target === state.role).map(n => `<div class="notification-item notification-row ${n.unread ? 'unread' : ''}" data-noti-id="${n.id}"><div><strong>${n.title}</strong><div class="muted">${n.body}</div></div><span class="pill ${n.unread ? 'warning' : 'success'}">${n.unread ? 'Sin leer' : 'Leída'}</span></div>`).join('')) || '<div class="empty-note">Sin notificaciones.</div>'}
            </div>
          </div>
          ${iconButton('headerLogout', ICONS.logout, 'Salir')}
          <button class="avatar-button avatar-btn" id="avatarBtn" title="Cambiar foto"><img src="assets/avatar-default.svg" alt="avatar" /></button>
          <button class="profile-chip user-chip" id="userNameLink" title="Mi perfil">
            <span class="role-kicker">${roleLabel()}</span>
            <span class="user-name">${user.name}</span>
          </button>
        </div>
      </header>
      <section class="content-grid">${renderView()}</section>
      <div class="footer-note">ISM ROBOSOFT© 2026<br/>by Ing. Fernando Gambino & C.P. - Todos los Derechos Registrados.</div>
      <input type="file" id="avatarInput" accept="image/*" hidden />
    </main>`;
  bindShellEvents();
}

function navLabel(view) {
  return { dashboard:'Dashboard', users:'Usuarios', roles:'Roles y permisos', teams:'Equipos', inventory:'Inventario', loanManagement:'Gestión de préstamos', campusTeacher:'Campus docente', campusStudent:'Campus alumno', library:'Biblioteca digital', notifications:'Notificaciones', profile:'Mi perfil', settings:'Configuraciones' }[view];
}
function navIcon(view) {
  return { dashboard:ICONS.dashboard, users:ICONS.users, roles:ICONS.roles, teams:ICONS.teams, inventory:ICONS.inventory, loanManagement:ICONS.roles, campusTeacher:ICONS.campus, campusStudent:ICONS.campus, library:ICONS.library, notifications:ICONS.bell, profile:ICONS.profile, settings:ICONS.settings }[view];
}

function statCard(label, value, text) { return `<div class="stat-card"><div>${label}</div><div class="value">${value}</div><div class="muted">${text}</div></div>`; }
function actionIcons() { return `<div class="action-row"><button class="btn btn-secondary btn-icon">${ICONS.eye}</button><button class="btn btn-secondary btn-icon">${ICONS.edit}</button><button class="btn btn-secondary btn-icon">${ICONS.delete}</button></div>`; }

function renderView() {
  switch (state.view) {
    case 'dashboard': return state.role === 'alumno' ? renderStudentDashboard() : renderDashboard();
    case 'users': return renderUsers();
    case 'roles': return renderRoles();
    case 'teams': return renderTeams();
    case 'inventory': return renderInventory();
    case 'loanManagement': return renderLoanManagement();
    case 'campusTeacher': return renderCampusTeacher();
    case 'campusStudent': return renderCampusStudent();
    case 'library': return renderLibrary();
    case 'notifications': return renderNotifications();
    case 'profile': return renderProfile();
    case 'settings': return renderSettings();
    default: return renderDashboard();
  }
}

function filterToolbar(module) {
  return `<div class="filter-row"><input placeholder="Buscar por nombre, código o detalle" data-filter="${module}"/><select data-filter="${module}"><option>Todos los estados</option><option>Activo</option><option>Pendiente</option><option>Disponible</option><option>Prestado</option></select><select data-filter="${module}"><option>Todos los tipos</option><option>Equipo</option><option>Insumo</option><option>Público</option><option>Privado</option></select><button class="btn btn-secondary" data-chart-module="${module}">${ICONS.chart} Ver gráficos</button></div>`;
}

function renderDashboard() {
  return `
    <div class="stats-grid">
      ${statCard('Usuarios', demo.users.length, 'Administradores, docentes y alumnos activos.')}
      ${statCard('Equipos', demo.teams.length, 'Equipos mixtos asignados a docentes.')}
      ${statCard('Inventario', demo.inventory.length, 'Registros de catálogo e insumos trazables.')}
      ${statCard('Préstamos abiertos', demo.loans.filter(l => l.status !== 'Devuelto').length, 'Con seguimiento y devolución pendiente.')}
    </div>
    <div class="twocol">
      <section class="panel">
        <div class="panel-title"><h2>Resumen operativo</h2><button class="btn btn-secondary" data-chart-module="dashboard">${ICONS.chart} Ver gráficos</button></div>
        <div class="cards-grid" style="grid-template-columns:1fr;">
          <div class="resource-card"><strong>ABM de usuarios</strong><div class="muted">Alta, baja y modificación con roles, permisos y perfiles.</div></div>
          <div class="resource-card"><strong>Campus docente</strong><div class="muted">Carga de módulos, lecciones, tareas y evaluativos estilo LMS.</div></div>
          <div class="resource-card"><strong>Inventario inteligente</strong><div class="muted">Trazabilidad por serie o código de barras, préstamos y devoluciones.</div></div>
        </div>
      </section>
      <section class="panel"><div class="panel-title"><h2>Alertas del día</h2></div>${demo.notifications.slice(0,4).map(n => `<div class="resource-card" style="min-height:auto"><strong>${n.title}</strong><div class="muted">${n.body}</div></div>`).join('')}</section>
    </div>
    <section class="panel">
      <div class="panel-title"><h2>Dashboard principal</h2><div class="toolbar"><button class="btn btn-secondary" data-chart-module="inventory">${ICONS.chart} Inventario</button><button class="btn btn-secondary" data-chart-module="loans">${ICONS.chart} Préstamos</button><button class="btn btn-secondary" data-chart-module="courses">${ICONS.chart} Cursos</button></div></div>
      <div class="chart-wrap"><canvas id="dashboardChart"></canvas></div>
    </section>`;
}

function renderStudentDashboard() {
  const enrolled = demo.courses.filter(c => c.enrolled.includes(DB.alumno.name));
  return `
    <div class="stats-grid">
      ${statCard('Cursos inscriptos', enrolled.length, 'Accesos activos en tu campus.')}
      ${statCard('Tareas', enrolled.reduce((a,c)=>a+c.items.filter(i=>i.kind==='task').length,0), 'Actividades pendientes esta semana.')}
      ${statCard('Evaluativos', enrolled.reduce((a,c)=>a+c.items.filter(i=>i.kind==='quiz').length,0), 'Instancias próximas de evaluación.')}
      ${statCard('Notificaciones', getUnreadCount(), 'Avisos del laboratorio y docentes.')}
    </div>
    <div class="twocol">
      <section class="panel">
        <div class="panel-title"><h2>Mi equipo de robótica</h2></div>
        <div class="resource-card" style="min-height:auto"><strong>${DB.alumno.team}</strong><div class="muted">Docentes responsables: María López y Lucas Méndez.</div></div>
        <div class="panel-title" style="margin-top:16px"><h2>Mis cursos</h2><button class="btn btn-primary" id="openCampusAlumno">Abrir campus alumno</button></div>
        <div class="cards-grid" style="grid-template-columns:1fr">${enrolled.map(courseCard).join('')}</div>
      </section>
      <section class="panel">
        <div class="panel-title"><h2>Biblioteca y avisos</h2></div>
        <div class="resource-card" style="min-height:auto"><strong>Material recomendado</strong><div class="muted">Manual Arduino ISM y guía de seguridad.</div></div>
        <div class="resource-card" style="min-height:auto"><strong>Acceso a cursos abiertos</strong><div class="muted">Podés sumarte con código de curso y clave.</div><button class="btn btn-secondary btn-sm" id="joinCourseBtn">Suscribirme a curso</button></div>
      </section>
    </div>`;
}

function renderUsers() {
  return `<section class="panel"><div class="panel-title"><div><h2>Usuarios registrados</h2><div class="muted">WhatsApp, fecha de nacimiento, curso/división o materia/título.</div></div><div class="toolbar"><button class="btn btn-secondary">${ICONS.import} Importar CSV</button><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button><button class="btn btn-primary">Nuevo usuario</button></div></div>${filterToolbar('users')}<div class="table-wrap"><table><thead><tr><th>Nombre</th><th>Rol</th><th>Email</th><th>WhatsApp</th><th>DNI</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${demo.users.map(u=>`<tr><td>${u.name}</td><td>${u.role}</td><td>${u.email}</td><td>${u.whatsapp}</td><td>${u.dni}</td><td>${statusPill(u.status)}</td><td>${actionIcons()}</td></tr>`).join('')}</tbody></table></div></section>`;
}
function renderRoles() { return `<section class="panel"><div class="panel-title"><h2>Perfiles y permisos</h2><div class="toolbar"><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button><button class="btn btn-primary">Nuevo perfil</button></div></div>${filterToolbar('roles')}<div class="cards-grid"><div class="resource-card"><strong>Administrador</strong><div class="muted">Administra todos los perfiles y permisos.</div></div><div class="resource-card"><strong>Docente</strong><div class="muted">Gestiona equipos, cursos y solicitudes de préstamo.</div></div><div class="resource-card"><strong>Alumno</strong><div class="muted">Accede solo a Campus Alumno, biblioteca y perfil.</div></div></div></section>`; }
function renderTeams() {
  return `<section class="panel"><div class="panel-title"><div><h2>Equipos del laboratorio</h2><div class="muted">Equipos mixtos con múltiples docentes y cursos/divisiones.</div></div><div class="toolbar"><button class="btn btn-secondary">${ICONS.import} Importar CSV</button><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button><button class="btn btn-primary">Nuevo equipo</button></div></div>${filterToolbar('teams')}<div class="table-wrap"><table><thead><tr><th>Equipo</th><th>Docentes</th><th>Cursos</th><th>Divisiones</th><th>Alumnos</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${demo.teams.map(t=>`<tr><td>${t.name}</td><td>${t.docentes.join(', ')}</td><td>${t.cursos.join(', ')}</td><td>${t.divisiones.join(', ')}</td><td>${t.alumnos}</td><td>${statusPill(t.status)}</td><td>${actionIcons()}</td></tr>`).join('')}</tbody></table></div></section>`;
}
function renderInventory() {
  const docenteActions = state.role === 'docente' ? `<button class="btn btn-primary" id="loanRequestBtn">Solicitud de préstamo</button>` : `<button class="btn btn-primary" id="newInventoryBtn">Nuevo insumo</button>`;
  return `<section class="panel"><div class="panel-title"><div><h2>Control y trazabilidad</h2><div class="muted">Cada insumo permite saber quién lo tiene, cuándo lo pidió, estado de entrega y devolución.</div></div><div class="toolbar"><button class="btn btn-secondary">${ICONS.import} Importar CSV</button><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button>${docenteActions}</div></div>${filterToolbar('inventory')}<div class="table-wrap"><table><thead><tr><th>Código</th><th>Ítem</th><th>Tipo</th><th>N° serie</th><th>Barcode</th><th>Estado</th><th>Condición</th><th>Asignado a</th><th>Docente</th><th>Pedido</th><th>Devolución</th><th>Ubicación</th><th>Acciones</th></tr></thead><tbody>${demo.inventory.map(i=>`<tr><td><strong>${i.code}</strong></td><td>${i.item}</td><td>${i.type}</td><td>${i.serial}</td><td>${i.barcode}</td><td>${statusPill(i.status)}</td><td>${i.condition}</td><td>${i.assigned}</td><td>${i.teacher}</td><td>${i.requested}</td><td>${i.returned}</td><td>${i.location}</td><td>${actionIcons()}</td></tr>`).join('')}</tbody></table></div></section>`;
}
function renderLoanManagement() {
  const data = state.role === 'admin' ? demo.loans : demo.loans.filter(l => l.requester === DB.docente.name);
  return `<section class="panel"><div class="panel-title"><div><h2>Centro de préstamos</h2><div class="muted">Solicitudes, franjas horarias, estados y devoluciones.</div></div><div class="toolbar"><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button>${state.role==='docente'?'<button class="btn btn-primary" id="loanRequestBtn2">Nueva solicitud</button>':''}</div></div>${filterToolbar('loans')}<div class="table-wrap"><table><thead><tr><th>Solicitante</th><th>Curso / equipo</th><th>Fecha</th><th>Horario</th><th>Insumos</th><th>Observaciones</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${data.map(l=>`<tr><td>${l.requester}</td><td>${l.team}</td><td>${l.date}</td><td>${l.from} a ${l.to}</td><td>${l.items.join(', ')}</td><td>${l.notes}</td><td>${statusPill(l.status)}</td><td>${state.role==='admin'?`<div class="action-row"><button class="btn btn-secondary btn-sm" data-approve-loan="${l.id}">Aprobar</button><button class="btn btn-secondary btn-sm" data-reject-loan="${l.id}">Rechazar</button><button class="btn btn-secondary btn-sm" data-return-loan="${l.id}">Marcar devolución</button></div>`:actionIcons()}</td></tr>`).join('')}</tbody></table></div></section>`;
}

function courseCard(c) {
  return `<article class="course-card"><div><strong>${c.title}</strong><div class="muted">${c.teacher} · ${c.team}</div></div><div class="muted">${c.description}</div><div class="muted">Código: <strong>${c.code}</strong> · Visibilidad: ${c.visibility}</div><div class="pill info">Progreso ${c.progress}%</div><div class="course-actions"><button class="btn btn-secondary btn-sm" data-view-course="${c.id}">${ICONS.eye} Ver curso</button></div></article>`;
}

function renderCampusTeacher() {
  const ownCourses = state.role === 'docente' ? demo.courses.filter(c => c.teacher === DB.docente.name) : demo.courses;
  return `<section class="panel"><div class="panel-title"><div><h2>Gestión de cursos</h2><div class="muted">El docente puede crear cursos, módulos, lecciones, tareas y evaluativos.</div></div><div class="toolbar"><button class="btn btn-secondary">${ICONS.import} Importar CSV</button><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button><button class="btn btn-primary" id="newCourseBtn">Nuevo curso</button></div></div>${filterToolbar('courses')}<div class="cards-grid">${ownCourses.map(courseCard).join('')}</div><div class="panel" style="margin-top:16px"><div class="panel-title"><h3>Cómo carga contenido el docente</h3></div><div class="builder-layout"><div class="outline-list"><div class="resource-card" style="min-height:auto"><strong>1. Crear curso</strong><div class="muted">Nombre, descripción, código automático, clave, visibilidad y equipos.</div></div><div class="resource-card" style="min-height:auto"><strong>2. Agregar módulos</strong><div class="muted">Organizá el contenido por unidades.</div></div><div class="resource-card" style="min-height:auto"><strong>3. Cargar lecciones</strong><div class="muted">Texto, video, enlaces y archivos adjuntos.</div></div><div class="resource-card" style="min-height:auto"><strong>4. Cargar tareas y evaluativos</strong><div class="muted">Consignas, puntajes, intentos y feedback.</div></div></div><div class="content-view"><h3>Editor rápido</h3><p class="muted">Usá <strong>Nuevo curso</strong> para crear un curso y luego <strong>Ver curso</strong> para inspeccionar cómo lo verá el alumno. En esta demo, los datos se guardan localmente en memoria del navegador.</p><div class="toolbar"><button class="btn btn-secondary" id="addLessonBtn">Agregar lección</button><button class="btn btn-secondary" id="addTaskBtn">Agregar tarea</button><button class="btn btn-secondary" id="addQuizBtn">Agregar evaluativo</button></div></div></div></div></section>`;
}

function renderCampusStudent() {
  const courses = demo.courses.filter(c => c.enrolled.includes(DB.alumno.name));
  if (!state.selectedCourseId) {
    return `<section class="panel"><div class="panel-title"><div><h2>Mis cursos</h2><div class="muted">Visualizá los cursos inscriptos o sumate con código y clave.</div></div><div class="toolbar"><button class="btn btn-secondary" id="joinCourseBtn2">Suscribirme con código</button><button class="btn btn-secondary" data-chart-module="courses">${ICONS.chart} Ver gráficos</button></div></div>${filterToolbar('studentCourses')}<div class="cards-grid">${courses.map(courseCard).join('')}</div></section>`;
  }
  const course = demo.courses.find(c => c.id === state.selectedCourseId);
  const currentItem = course.items.find(i => i.id === state.selectedCourseItemId) || course.items[0];
  state.selectedCourseItemId = currentItem.id;
  const modules = [...new Set(course.items.map(i => i.module))];
  return `<section class="panel"><div class="panel-title"><div><h2>${course.title}</h2><div class="muted">${course.teacher} · Código ${course.code}</div></div><div class="toolbar"><button class="btn btn-secondary" id="backToCampusStudent">Volver</button></div></div><div class="lms-layout"><aside class="outline-list">${modules.map(module => `<div><strong>${module}</strong>${course.items.filter(i=>i.module===module).map(i=>`<div class="outline-item ${currentItem.id===i.id?'active':''}" data-course-item="${i.id}">${i.kind==='lesson'?'📘':i.kind==='task'?'📝':'✅'} ${i.title}<div class="muted">${i.kind==='lesson'?(i.duration||''):i.kind==='task'?(i.duration||''):('Evaluativo')}</div></div>`).join('')}</div>`).join('')}</aside><div class="content-view">${renderCourseItem(currentItem)}</div></div></section>`;
}

function renderCourseItem(item) {
  if (item.kind === 'lesson') {
    return `<h2>${item.title}</h2><p class="muted">${item.date} · ${item.duration}</p><p>${item.body}</p><iframe class="video-frame" src="${item.video}" title="video" allowfullscreen></iframe><div class="task-box"><strong>Archivos adjuntos</strong>${item.attachments.length ? `<table><thead><tr><th>Nombre</th><th>Tipo</th><th>Tamaño</th><th>Descarga</th></tr></thead><tbody>${item.attachments.map(a=>`<tr><td>${a.name}</td><td>${a.type}</td><td>${a.size}</td><td><button class="btn btn-secondary btn-sm">Descargar</button></td></tr>`).join('')}</tbody></table>` : '<div class="muted">Sin archivos adjuntos.</div>'}</div><div class="toolbar" style="margin-top:14px"><button class="btn btn-primary">Completar</button></div>`;
  }
  if (item.kind === 'task') {
    return `<h2>${item.title}</h2><p>Duración: ${item.duration} · Total: ${item.points} puntos · Aprobación: ${item.passing} puntos · Reintentos: ${item.retries}</p><div class="task-box"><strong>Instrucciones</strong><ol>${item.instructions.map(i=>`<li>${i}</li>`).join('')}</ol></div><div class="task-box"><strong>Se requiere entrega</strong><ul>${item.deliverables.map(i=>`<li>${i}</li>`).join('')}</ul></div><div class="toolbar"><button class="btn btn-primary" id="submitTaskBtn">Entregar tarea</button></div>`;
  }
  return `<h2>${item.title}</h2><div class="task-box"><strong>Pregunta 1 de 1</strong><p>${item.question}</p>${item.options.map((option,idx)=>`<button type="button" class="quiz-option" data-quiz-choice="${idx}"><span class="quiz-mark"></span><span>${String.fromCharCode(97+idx)}) ${option}</span></button>`).join('')}<div class="toolbar"><button class="btn btn-secondary" id="reviewQuizBtn">Revisar respuestas</button></div><div id="quizFeedback" class="task-box" style="display:none"></div></div>`;
}

function renderLibrary() {
  return `<section class="panel"><div class="panel-title"><div><h2>Biblioteca digital</h2><div class="muted">Repositorio de documentos, videos, PDFs, TXT, ZIP y links externos como GitHub o Drive.</div></div><div class="toolbar"><button class="btn btn-primary" id="newResourceBtn">Nuevo recurso</button><button class="btn btn-secondary">${ICONS.import} Importar CSV</button><button class="btn btn-secondary">${ICONS.export} Exportar CSV</button></div></div>${filterToolbar('library')}<div class="cards-grid">${demo.resources.map(r => `<article class="resource-card"><strong>${r.title}</strong><div class="muted">${r.category}</div><div>${r.description}</div><div class="pill info">${r.type}</div><div class="muted">Origen: ${r.source}</div><div class="course-actions"><button class="btn btn-secondary btn-sm">${ICONS.eye} Ver</button></div></article>`).join('')}</div><div class="panel" style="margin-top:16px"><div class="panel-title"><h3>Cómo agregar recursos</h3></div><ol class="muted"><li>Hacé clic en <strong>Nuevo recurso</strong>.</li><li>Elegí el tipo: PDF, Video, Documento, TXT, ZIP, Link o Repositorio GitHub.</li><li>Completá título, categoría, descripción y archivo o URL.</li><li>Guardá. El recurso se agrega en la grilla y queda disponible para docentes y alumnos según el rol.</li></ol></div></section>`;
}

function renderNotifications() {
  const list = demo.notifications.filter(n => n.target === 'all' || n.target === state.role || state.role === 'admin');
  return `<section class="panel"><div class="panel-title"><div><h2>Centro de notificaciones</h2><div class="muted">Envíos masivos, individuales, por equipo o selección múltiple.</div></div><div class="toolbar"><button class="btn btn-primary" id="sendNotificationBtn">Enviar notificación</button></div></div>${list.map(n=>`<div class="resource-card" style="min-height:auto"><strong>${n.title}</strong><div class="muted">${n.body}</div><div class="pill ${n.unread?'warning':'success'}">${n.unread?'Sin leer':'Leída'}</div></div>`).join('')}</section>`;
}
function renderProfile() { const user = DB[state.role]; return `<section class="panel"><div class="panel-title"><h2>Mi perfil</h2><button class="btn btn-primary" id="editProfileBtn">Editar datos</button></div><div class="cards-grid" style="grid-template-columns:1fr 1fr"><div class="resource-card"><strong>Nombre</strong><div>${user.name}</div></div><div class="resource-card"><strong>Email</strong><div>${user.email}</div></div><div class="resource-card"><strong>Rol</strong><div>${roleLabel()}</div></div><div class="resource-card"><strong>${state.role==='alumno'?'Equipo':'Área'}</strong><div>${state.role==='alumno'?DB.alumno.team:(state.role==='docente'?DB.docente.subject:'Administración general')}</div></div></div></section>`; }
function renderSettings() { return `<section class="panel"><div class="panel-title"><h2>Configuraciones del sistema</h2></div><div class="cards-grid"><div class="resource-card"><strong>Logo institucional</strong><div class="muted">Podés reemplazar el logo del sistema.</div><button class="btn btn-secondary btn-sm">Cargar logo</button></div><div class="resource-card"><strong>Tema</strong><div class="muted">Alterná entre oscuro y claro.</div><button class="btn btn-secondary btn-sm" id="themeToggle2">Cambiar tema</button></div></div></section>`; }

function statusPill(status) {
  const cls = /Activo|Disponible|Aprobado|Publicado|Leída|Devuelto/i.test(status) ? 'success' : /Pendiente|Prestado/i.test(status) ? 'warning' : /mantenimiento|Rechazado|Sin leer/i.test(status) ? 'danger' : 'info';
  return `<span class="pill ${cls}">${status}</span>`;
}

function bindShellEvents() {
  document.querySelectorAll('[data-view]').forEach(a => a.onclick = e => { e.preventDefault(); state.view = a.dataset.view; if(state.view!=='campusStudent'){state.selectedCourseId=null; state.selectedCourseItemId=null;} rerender(); });
  document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
  document.getElementById('themeToggle2')?.addEventListener('click', toggleTheme);
  document.getElementById('fullscreenBtn')?.addEventListener('click', () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen());
  document.getElementById('bellBtn')?.addEventListener('click', () => { state.notificationsOpen = !state.notificationsOpen; appShell(); });
  document.querySelectorAll('.notification-item').forEach(n => n.onclick = () => { const id = +n.dataset.notiId; const item = demo.notifications.find(x => x.id===id); if(item) item.unread = false; state.notificationsOpen = false; state.view = 'notifications'; rerender(); });
  document.getElementById('avatarBtn')?.addEventListener('click', () => document.getElementById('avatarInput').click());
  document.getElementById('avatarInput')?.addEventListener('change', () => Swal.fire({icon:'success', title:'Foto actualizada', text:'La imagen de perfil fue seleccionada correctamente.'}));
  document.getElementById('userNameLink')?.addEventListener('click', () => { state.view = 'profile'; rerender(); });
  document.getElementById('sidebarLogout')?.addEventListener('click', logout);
  document.getElementById('headerLogout')?.addEventListener('click', logout);
  document.getElementById('loanRequestBtn')?.addEventListener('click', openLoanRequest);
  document.getElementById('loanRequestBtn2')?.addEventListener('click', openLoanRequest);
  document.getElementById('newResourceBtn')?.addEventListener('click', openResourceModal);
  document.getElementById('newCourseBtn')?.addEventListener('click', openCourseModal);
  document.getElementById('addLessonBtn')?.addEventListener('click', () => openContentModal('lesson'));
  document.getElementById('addTaskBtn')?.addEventListener('click', () => openContentModal('task'));
  document.getElementById('addQuizBtn')?.addEventListener('click', () => openContentModal('quiz'));
  document.getElementById('sendNotificationBtn')?.addEventListener('click', openNotificationModal);
  document.getElementById('openCampusAlumno')?.addEventListener('click', () => { state.view = 'campusStudent'; rerender(); });
  document.getElementById('joinCourseBtn')?.addEventListener('click', openJoinCourseModal);
  document.getElementById('joinCourseBtn2')?.addEventListener('click', openJoinCourseModal);
  document.querySelectorAll('[data-view-course]').forEach(btn => btn.onclick = () => { state.selectedCourseId = +btn.dataset.viewCourse; state.selectedCourseItemId = null; state.view = state.role === 'alumno' ? 'campusStudent' : 'campusTeacher'; rerender(); });
  document.getElementById('backToCampusStudent')?.addEventListener('click', () => { state.selectedCourseId = null; state.selectedCourseItemId = null; rerender(); });
  document.querySelectorAll('[data-course-item]').forEach(btn => btn.onclick = () => { state.selectedCourseItemId = btn.dataset.courseItem; rerender(); });
  document.getElementById('submitTaskBtn')?.addEventListener('click', () => Swal.fire({icon:'success', title:'Tarea enviada', text:'La entrega quedó registrada en la demo.'}));
  document.querySelectorAll('[data-quiz-choice]').forEach(btn => btn.onclick = () => { document.querySelectorAll('[data-quiz-choice]').forEach(x => { x.dataset.selected='0'; x.classList.remove('selected'); }); btn.dataset.selected='1'; btn.classList.add('selected'); });
  document.getElementById('reviewQuizBtn')?.addEventListener('click', reviewQuiz);
  document.querySelectorAll('[data-chart-module]').forEach(btn => btn.onclick = () => openChartModal(btn.dataset.chartModule));
  document.querySelectorAll('[data-approve-loan]').forEach(btn => btn.onclick = () => updateLoanStatus(+btn.dataset.approveLoan, 'Aprobado'));
  document.querySelectorAll('[data-reject-loan]').forEach(btn => btn.onclick = () => updateLoanStatus(+btn.dataset.rejectLoan, 'Rechazado'));
  document.querySelectorAll('[data-return-loan]').forEach(btn => btn.onclick = () => updateLoanStatus(+btn.dataset.returnLoan, 'Devuelto'));
  if (document.getElementById('dashboardChart')) mountDashboardChart();
}

function mountDashboardChart() {
  const ctx = document.getElementById('dashboardChart');
  if (!ctx) return;
  new Chart(ctx, { type:'bar', data:{ labels:['Usuarios','Equipos','Inventario','Préstamos'], datasets:[{ label:'Totales', data:[demo.users.length, demo.teams.length, demo.inventory.length, demo.loans.length] }] }, options:{ responsive:true, maintainAspectRatio:false } });
}

function toggleTheme() { state.theme = state.theme === 'dark' ? 'light' : 'dark'; localStorage.setItem('ism-theme', state.theme); rerender(); }
function logout(e){ if(e) e.preventDefault(); localStorage.removeItem('ism-role'); window.location.href='index.html'; }
function rerender() { appShell(); }

function inputRow(label, fieldHtml, full=false){
  return `<label class="${full ? 'full-span' : ''}"><span>${label}</span>${fieldHtml}</label>`;
}

function modalBase(title, html, options={}) {
  return Swal.fire({
    title,
    html,
    focusConfirm: false,
    width: options.width || 820,
    confirmButtonText: options.confirmButtonText || 'Guardar',
    customClass: { popup: 'swal-modal' },
    ...options
  });
}

function openChartModal(module) {
  const map = {
    users: {labels:['Admin','Docente','Alumno'], data:[1,2,2]},
    inventory: {labels:['Disponible','Prestado','Mantenimiento'], data:[3,1,1]},
    loans: {labels:['Pendiente','Aprobado','Rechazado','Devuelto'], data:[demo.loans.filter(x=>x.status==='Pendiente').length,demo.loans.filter(x=>x.status==='Aprobado').length,demo.loans.filter(x=>x.status==='Rechazado').length,demo.loans.filter(x=>x.status==='Devuelto').length]},
    courses: {labels:demo.courses.map(c=>c.title), data:demo.courses.map(c=>c.progress)},
    dashboard: {labels:['Usuarios','Equipos','Insumos','Préstamos'], data:[demo.users.length,demo.teams.length,demo.inventory.length,demo.loans.length]},
    teams: {labels:demo.teams.map(t=>t.name), data:demo.teams.map(t=>t.alumnos)},
    library: {labels:['PDF','Video','Documento','ZIP','Link'], data:[2,1,0,0,0]},
    studentCourses: {labels:demo.courses.filter(c=>c.enrolled.includes(DB.alumno.name)).map(c=>c.title), data:demo.courses.filter(c=>c.enrolled.includes(DB.alumno.name)).map(c=>c.progress)}
  };
  const picked = map[module] || map.dashboard;
  Swal.fire({
    title: 'Gráficos del módulo',
    html: `<div class="toolbar" style="margin-bottom:10px"><button class="btn btn-secondary btn-sm" onclick="window.__chartType='bar'">Barra</button><button class="btn btn-secondary btn-sm" onclick="window.__chartType='pie'">Torta</button><button class="btn btn-secondary btn-sm" onclick="window.__chartType='line'">Línea</button></div><div style="height:320px"><canvas id="modalChart"></canvas></div>`,
    width: 860,
    didOpen: () => {
      window.__chartType = 'bar';
      const make = (type='bar') => {
        if (window.__chartObj) window.__chartObj.destroy();
        window.__chartObj = new Chart(document.getElementById('modalChart'), { type, data:{ labels:picked.labels, datasets:[{ label:'Valores', data:picked.data }] }, options:{ responsive:true, maintainAspectRatio:false } });
      };
      make('bar');
      document.querySelectorAll('.swal2-container .btn-sm').forEach(btn => btn.onclick = () => make(btn.textContent.toLowerCase().includes('barra') ? 'bar' : btn.textContent.toLowerCase().includes('torta') ? 'pie' : 'line'));
    }
  });
}

function openResourceModal() {
  const html = `<div class="swal-form-grid">
    ${inputRow('Título', '<input id="resTitle" class="swal2-input" placeholder="Ej. Manual de sensores" />')}
    ${inputRow('Categoría', '<input id="resCategory" class="swal2-input" placeholder="Electrónica, Normas, Arduino..." />')}
    ${inputRow('Tipo de recurso', '<select id="resType" class="swal2-select"><option>PDF</option><option>Video</option><option>Documento</option><option>TXT</option><option>ZIP</option><option>Link</option><option>Repositorio GitHub</option></select>')}
    ${inputRow('Archivo o URL', '<input id="resUrl" class="swal2-input" placeholder="https://... o nombre del archivo" />')}
    ${inputRow('Descripción', '<textarea id="resDesc" class="swal2-textarea" placeholder="Describe el material y su uso" rows="4"></textarea>', true)}
  </div>`;
  modalBase('Nuevo recurso', html, {
    confirmButtonText: 'Agregar recurso',
    preConfirm: () => {
      const title = document.getElementById('resTitle').value.trim();
      if (!title) return Swal.showValidationMessage('Ingresá un título');
      return {
        title,
        category: document.getElementById('resCategory').value.trim() || 'General',
        type: document.getElementById('resType').value,
        url: document.getElementById('resUrl').value.trim() || '#',
        source: document.getElementById('resType').value,
        description: document.getElementById('resDesc').value.trim() || 'Sin descripción.'
      };
    }
  }).then(res => {
    if (!res.isConfirmed) return;
    demo.resources.unshift({ id: Date.now(), ...res.value });
    Swal.fire({ icon:'success', title:'Recurso agregado', text:'La biblioteca digital ya muestra el nuevo recurso.' });
    rerender();
  });
}

function openNotificationModal() {
  const html = `<div class="swal-form-grid">
    ${inputRow('Título', '<input id="notifTitle" class="swal2-input" placeholder="Aviso importante" />', true)}
    ${inputRow('Mensaje', '<textarea id="notifBody" class="swal2-textarea" placeholder="Escribí el detalle de la notificación" rows="4"></textarea>', true)}
    ${inputRow('Destinatarios', '<select id="notifTarget" class="swal2-select"><option value="all">Todos los usuarios</option><option value="admin">Administradores</option><option value="docente">Docentes</option><option value="alumno">Alumnos</option></select>')}
    ${inputRow('Equipo / selección múltiple', '<input id="notifTeam" class="swal2-input" placeholder="Ej. Equipo Rover A o lista de usuarios" />')}
  </div>`;
  modalBase('Enviar notificación', html, {
    confirmButtonText: 'Enviar',
    preConfirm: () => {
      const title = document.getElementById('notifTitle').value.trim();
      const body = document.getElementById('notifBody').value.trim();
      if (!title || !body) return Swal.showValidationMessage('Completá título y mensaje');
      return { title, body, target: document.getElementById('notifTarget').value };
    }
  }).then(res => {
    if (!res.isConfirmed) return;
    demo.notifications.unshift({ id: Date.now(), unread: true, type:'info', ...res.value });
    Swal.fire({ icon:'success', title:'Notificación enviada', text:'La notificación fue distribuida a los destinatarios seleccionados.' });
    rerender();
  });
}

function openLoanRequest() {
  const options = demo.inventory.filter(i => i.status === 'Disponible').map(i => `<option value="${i.code}">${i.code} · ${i.item}</option>`).join('');
  const html = `<div class="swal-form-grid">
      ${inputRow('Curso / equipo', '<input id="loanTeam" class="swal2-input" placeholder="Ej. Equipo Rover A / 6°C" />')}
      ${inputRow('Fecha de uso', '<input id="loanDate" type="date" class="swal2-input" />')}
      ${inputRow('Hora desde', '<input id="loanFrom" type="time" class="swal2-input" />')}
      ${inputRow('Hora hasta', '<input id="loanTo" type="time" class="swal2-input" />')}
      ${inputRow('Insumos solicitados', `<select id="loanItems" class="swal2-select" multiple size="7">${options}</select>`, true)}
      ${inputRow('Observaciones', '<textarea id="loanNotes" class="swal2-textarea" placeholder="Detalle del pedido, condición esperada y objetivo de uso" rows="4"></textarea>', true)}
    </div>`;
  modalBase('Solicitud de préstamo', html, {
    confirmButtonText: 'Solicitar',
    width: 860,
    preConfirm: () => {
      const team = document.getElementById('loanTeam').value.trim();
      const date = document.getElementById('loanDate').value;
      const from = document.getElementById('loanFrom').value;
      const to = document.getElementById('loanTo').value;
      const items = [...document.getElementById('loanItems').selectedOptions].map(x=>x.value);
      if (!team || !date || !from || !to || !items.length) return Swal.showValidationMessage('Completá equipo, fecha, franja horaria e insumos');
      return { team, date, from, to, items, notes: document.getElementById('loanNotes').value.trim() || 'Sin observaciones' };
    }
  }).then(res => {
    if (!res.isConfirmed) return;
    demo.loans.unshift({ id: Date.now(), role: 'docente', requester: DB.docente.name, status: 'Pendiente', ...res.value });
    demo.notifications.unshift({ id: Date.now()+1, title: 'Nueva solicitud de préstamo', body: `${DB.docente.name} solicitó ${res.value.items.join(', ')} para ${res.value.team}.`, unread: true, target: 'admin', type: 'prestamo' });
    Swal.fire({ icon:'success', title:'Solicitud enviada', text:'La solicitud quedó registrada y se notificó al administrador.' });
    rerender();
  });
}

function updateLoanStatus(id, status) {
  const loan = demo.loans.find(l => l.id === id);
  if (!loan) return;
  loan.status = status;
  demo.notifications.unshift({ id: Date.now(), title: `Préstamo ${status.toLowerCase()}`, body: `La solicitud de ${loan.requester} para ${loan.team} fue ${status.toLowerCase()}.`, unread: true, target: 'docente', type: 'prestamo' });
  rerender();
}

function openCourseModal() {
  const html = `<div class="swal-form-grid">
           ${inputRow('Nombre del curso', '<input id="courseTitle" class="swal2-input" placeholder="Ej. Robótica aplicada" />')}
           ${inputRow('Descripción', '<textarea id="courseDesc" class="swal2-textarea" placeholder="Objetivos, contenidos y alcance" rows="4"></textarea>')}
           ${inputRow('Visibilidad', '<select id="courseVisibility" class="swal2-select"><option>Público</option><option>Privado</option></select>')}
           ${inputRow('Equipo / cursos permitidos', '<input id="courseTeam" class="swal2-input" placeholder="Ej. Equipo Rover A · 6°C" />')}
           ${inputRow('Clave de acceso', '<input id="courseKey" class="swal2-input" placeholder="Definí una clave para el ingreso" />')}
         </div>`;
  modalBase('Nuevo curso', html, {
    confirmButtonText: 'Crear curso',
    width: 860,
    preConfirm: () => {
      const title = document.getElementById('courseTitle').value.trim();
      if (!title) return Swal.showValidationMessage('Ingresá el nombre del curso');
      return {
        id: Date.now(),
        title,
        teacher: state.role === 'docente' ? DB.docente.name : 'María López',
        team: document.getElementById('courseTeam').value.trim() || 'Visible para todos',
        visibility: document.getElementById('courseVisibility').value,
        code: `ISM-${title.substring(0,3).toUpperCase()}-${String(Date.now()).slice(-3)}`,
        accessKey: document.getElementById('courseKey').value.trim() || '1234',
        progress: 0,
        status: 'Borrador',
        description: document.getElementById('courseDesc').value.trim() || 'Sin descripción.',
        enrolled: [],
        items: []
      };
    }
  }).then(res => {
    if (!res.isConfirmed) return;
    demo.courses.unshift(res.value);
    Swal.fire({ icon:'success', title:'Curso creado', text:`Código generado: ${res.value.code}` });
    rerender();
  });
}

function openContentModal(kind) {
  if (!demo.courses.length) return Swal.fire({icon:'warning', title:'Primero creá un curso'});
  Swal.fire({
    title: `Agregar ${kind==='lesson'?'lección':kind==='task'?'tarea':'evaluativo'}`,
    html: `<select id="contentCourse" class="swal2-select">${demo.courses.map(c=>`<option value="${c.id}">${c.title}</option>`).join('')}</select>
           <input id="contentModule" class="swal2-input" placeholder="Módulo" />
           <input id="contentTitle" class="swal2-input" placeholder="Título" />
           <textarea id="contentBody" class="swal2-textarea" placeholder="Contenido / instrucciones"></textarea>`,
    preConfirm: () => {
      const title = document.getElementById('contentTitle').value.trim();
      if (!title) return Swal.showValidationMessage('Ingresá un título');
      return { courseId:+document.getElementById('contentCourse').value, module: document.getElementById('contentModule').value.trim() || 'Módulo sin nombre', title, body: document.getElementById('contentBody').value.trim() || 'Contenido pendiente.' };
    }
  }).then(res => {
    if (!res.isConfirmed) return;
    const course = demo.courses.find(c => c.id === res.value.courseId);
    if (!course) return;
    let item;
    if (kind === 'lesson') item = { id: `l${Date.now()}`, kind:'lesson', module:res.value.module, title:res.value.title, date:'Hoy', duration:'45 minutos', body:res.value.body, video:'https://www.youtube.com/embed/dQw4w9WgXcQ', attachments:[] };
    if (kind === 'task') item = { id: `t${Date.now()}`, kind:'task', module:res.value.module, title:res.value.title, duration:'7 días', points:10, passing:7, retries:3, instructions:[res.value.body], deliverables:['Entrega en archivo o texto.'] };
    if (kind === 'quiz') item = { id: `q${Date.now()}`, kind:'quiz', module:res.value.module, title:res.value.title, time:'20:00', question:res.value.body || 'Nueva pregunta', options:['Opción A','Opción B','Opción C','Opción D'], correct:0, feedback:'Feedback de ejemplo.' };
    course.items.push(item);
    Swal.fire({ icon:'success', title:'Contenido agregado', text:'El nuevo contenido ya aparece dentro del curso.' });
    rerender();
  });
}

function openJoinCourseModal() {
  Swal.fire({ title:'Suscribirme a curso', html:`<input id="joinCode" class="swal2-input" placeholder="Código del curso" /><input id="joinKey" class="swal2-input" placeholder="Clave de acceso" />`, preConfirm:()=>{const code=document.getElementById('joinCode').value.trim();const key=document.getElementById('joinKey').value.trim();if(!code||!key)return Swal.showValidationMessage('Ingresá código y clave');return {code,key};}}).then(res=>{if(!res.isConfirmed)return; const course=demo.courses.find(c=>c.code===res.value.code && c.accessKey===res.value.key); if(!course){Swal.fire({icon:'error',title:'Datos inválidos',text:'No se encontró un curso con ese código y clave.'}); return;} if(!course.enrolled.includes(DB.alumno.name)) course.enrolled.push(DB.alumno.name); Swal.fire({icon:'success',title:'Inscripción confirmada',text:`Ya tenés acceso a ${course.title}.`}); rerender();});
}

function reviewQuiz() {
  const course = demo.courses.find(c => c.id === state.selectedCourseId);
  const item = course.items.find(i => i.id === state.selectedCourseItemId);
  const selected = [...document.querySelectorAll('[data-quiz-choice]')].findIndex(x => x.dataset.selected === '1');
  if (selected === -1) return Swal.fire({icon:'warning', title:'Elegí una opción'});
  document.querySelectorAll('[data-quiz-choice]').forEach((opt, idx) => opt.classList.add(idx === item.correct ? 'correct' : idx === selected ? 'wrong' : ''));
  const fb = document.getElementById('quizFeedback');
  fb.style.display = 'block';
  fb.innerHTML = `<strong>${selected===item.correct?'Correcto':'Incorrecto'}</strong><div>${item.feedback}</div>`;
}

if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
appShell();
