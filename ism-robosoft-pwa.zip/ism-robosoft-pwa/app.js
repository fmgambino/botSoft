const icons = {
  dashboard: `<svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10Zm10 8h8V11h-8v10ZM3 21h8v-6H3v6Zm10-10h8V3h-8v8Z"></path></svg>`,
  users: `<svg viewBox="0 0 24 24"><path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4ZM8 12a3 3 0 1 0-3-3 3 3 0 0 0 3 3Zm8 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4ZM8 14c-.29 0-.62.02-.97.05C5.7 14.16 2 14.82 2 17v2h4v-1c0-1.46.8-2.68 2.29-3.64A9.79 9.79 0 0 0 8 14Z"></path></svg>`,
  roles: `<svg viewBox="0 0 24 24"><path d="m12 1 9 4v6c0 5.55-3.84 10.74-9 12-5.16-1.26-9-6.45-9-12V5l9-4Zm0 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm0 6c-1.83 0-3.8.93-4 2v1h8v-1c-.2-1.07-2.17-2-4-2Z"></path></svg>`,
  team: `<svg viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.79 2.99-4S17.66 3 16 3s-3 1.79-3 4 1.34 4 3 4Zm-8 0c1.66 0 2.99-1.79 2.99-4S9.66 3 8 3 5 4.79 5 7s1.34 4 3 4Zm0 2c-2.33 0-7 1.17-7 3.5V20h14v-3.5C15 14.17 10.33 13 8 13Zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.95 1.97 3.45V20h6v-3.5c0-2.33-4.67-3.5-7-3.5Z"></path></svg>`,
  inventory: `<svg viewBox="0 0 24 24"><path d="M21 16V8l-9-5-9 5v8l9 5 9-5Zm-9 2.7-6-3.33V9.3l6 3.33 6-3.33v6.07l-6 3.33Zm0-8.37L6.04 7 12 3.7 17.96 7 12 10.33Z"></path></svg>`,
  courses: `<svg viewBox="0 0 24 24"><path d="M12 3 1 9l11 6 9-4.91V17h2V9L12 3Zm-7 9.18V17l7 4 7-4v-4.82l-7 3.82-7-3.82Z"></path></svg>`,
  library: `<svg viewBox="0 0 24 24"><path d="M18 2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10v-2H8V4h10V2Zm-3 4h5a1 1 0 0 1 1 1v15l-3-2-3 2V7a1 1 0 0 1 1-1Z"></path></svg>`,
  notifications: `<svg viewBox="0 0 24 24"><path d="M12 22a2.5 2.5 0 0 0 2.45-2h-4.9A2.5 2.5 0 0 0 12 22Zm7-6V11a7 7 0 1 0-14 0v5L3 18v1h18v-1l-2-2Z"></path></svg>`,
  profile: `<svg viewBox="0 0 24 24"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4Z"></path></svg>`,
  settings: `<svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.6-.22l-2.39.96a7.16 7.16 0 0 0-1.63-.94l-.36-2.54a.49.49 0 0 0-.49-.42h-3.84a.49.49 0 0 0-.49.42l-.36 2.54c-.58.22-1.12.53-1.63.94l-2.39-.96a.5.5 0 0 0-.6.22L2.71 8.84a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94L2.83 14.52a.5.5 0 0 0-.12.64l1.92 3.32c.13.22.39.31.6.22l2.39-.96c.51.41 1.05.72 1.63.94l.36 2.54c.05.24.25.42.49.42h3.84c.24 0 .44-.18.49-.42l.36-2.54c.58-.22 1.12-.53 1.63-.94l2.39.96c.22.09.47 0 .6-.22l1.92-3.32a.5.5 0 0 0-.12-.64l-2.03-1.58ZM12 15.5A3.5 3.5 0 1 1 12 8a3.5 3.5 0 0 1 0 7.5Z"></path></svg>`,
  logout: `<svg viewBox="0 0 24 24"><path d="M10 17v-3H3v-4h7V7l5 5-5 5Zm4-14h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5v-2h5V5h-5V3Z"></path></svg>`,
  eye: `<svg viewBox="0 0 24 24"><path d="M12 5c5.05 0 9.27 3.11 11 7-1.73 3.89-5.95 7-11 7S2.73 15.89 1 12c1.73-3.89 5.95-7 11-7Zm0 2C8.36 7 5.17 9.06 3.33 12 5.17 14.94 8.36 17 12 17s6.83-2.06 8.67-5C18.83 9.06 15.64 7 12 7Zm0 2.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"></path></svg>`,
  edit: `<svg viewBox="0 0 24 24"><path d="m3 17.25 9.81-9.81 3.75 3.75L6.75 21H3v-3.75ZM14.87 5.38l1.77-1.77a1.5 1.5 0 0 1 2.12 0l1.63 1.63a1.5 1.5 0 0 1 0 2.12l-1.77 1.77-3.75-3.75Z"></path></svg>`,
  trash: `<svg viewBox="0 0 24 24"><path d="M6 7h12l-1 14H7L6 7Zm3-4h6l1 2h4v2H4V5h4l1-2Z"></path></svg>`
};

const demoState = {
  notifications: [
    { id: 1, title: 'Nueva solicitud de inventario', message: 'El equipo RoboAlpha pidió 2 sensores ultrasónicos.', unread: true },
    { id: 2, title: 'Evaluativo publicado', message: 'Electrónica Básica ya tiene evaluación disponible.', unread: true },
    { id: 3, title: 'Cambio de perfil', message: 'Se otorgó permiso de biblioteca a un docente.', unread: false },
  ],
  users: [
    { full_name: 'Fernando Gambino', role: 'Administrador', email: 'fgambino@ism.edu.ar', whatsapp: '+54 9 11 5555 1111', dni: '30111222', status: 'Activo' },
    { full_name: 'María López', role: 'Docente', email: 'mlopez@ism.edu.ar', whatsapp: '+54 9 11 4444 2222', dni: '28999888', status: 'Activo' },
    { full_name: 'Thiago Luna', role: 'Alumno', email: 'thiago.luna@ism.edu.ar', whatsapp: '+54 9 11 3333 1111', dni: '49442589', status: 'Pendiente' },
  ],
  inventory: [
    { code: 'ARD-001', name: 'Arduino Uno R3', category: 'Microcontroladores', stock: 12, min_stock: 5, status: 'Disponible' },
    { code: 'SEN-014', name: 'Sensor ultrasónico HC-SR04', category: 'Sensores', stock: 4, min_stock: 6, status: 'Bajo stock' },
    { code: 'ROB-007', name: 'Kit chasis robot 2WD', category: 'Kits', stock: 8, min_stock: 3, status: 'Disponible' },
  ],
  equipment: [
    { name: 'RoboAlpha', leader: 'Thiago Luna', teacher: 'María López', members: 4, course: '6°C', status: 'Activo' },
    { name: 'MechBots', leader: 'Tomás Cáceres', teacher: 'María López', members: 5, course: '5°A', status: 'Activo' },
  ],
  modules: [
    { name: 'Introducción a la robótica', lessons: 5, tasks: 3, evaluative: 'Sí', audience: 'Alumnos 1er tramo' },
    { name: 'Electrónica aplicada', lessons: 7, tasks: 4, evaluative: 'Sí', audience: 'Alumnos avanzados' },
  ],
  library: [
    { title: 'Manual de Arduino', type: 'PDF', access: 'Docentes y Alumnos' },
    { title: 'Reglamento de laboratorio', type: 'PDF', access: 'Todos' },
    { title: 'Catálogo de sensores 2026', type: 'Drive / Link', access: 'Administradores' },
  ]
};

const navByRole = {
  administrator: [
    ['dashboard', 'Dashboard'], ['users', 'Usuarios'], ['roles', 'Roles y permisos'], ['team', 'Equipos'], ['inventory', 'Inventario'],
    ['courses', 'Campus docente'], ['library', 'Biblioteca digital'], ['notifications', 'Notificaciones'], ['profile', 'Mi perfil'], ['settings', 'Configuraciones']
  ],
  teacher: [
    ['dashboard', 'Dashboard'], ['team', 'Equipos asignados'], ['courses', 'Módulos y tareas'], ['library', 'Biblioteca digital'], ['notifications', 'Notificaciones'], ['profile', 'Mi perfil']
  ],
  student: [
    ['dashboard', 'Dashboard'], ['courses', 'Mis módulos'], ['library', 'Biblioteca digital'], ['notifications', 'Notificaciones'], ['profile', 'Mi perfil']
  ]
};

let currentUser = JSON.parse(localStorage.getItem('ism_demo_user') || 'null') || { name: 'Usuario', role: 'administrator', avatar_url: './assets/avatar-default.svg' };
let currentProfile = null;
let roleKey = currentUser.role || 'administrator';

const appContent = document.getElementById('appContent');
const navMenu = document.getElementById('navMenu');
const pageTitle = document.getElementById('pageTitle');
const pageSubtitle = document.getElementById('pageSubtitle');
const notificationCount = document.getElementById('notificationCount');
const notificationsPreview = document.getElementById('notificationsPreview');
const headerUserName = document.getElementById('headerUserName');
const headerAvatar = document.getElementById('headerAvatar');
const appShell = document.getElementById('appShell');

function setHeaderUser() {
  headerUserName.textContent = currentProfile?.full_name || currentUser.name || 'Usuario';
  headerAvatar.src = currentProfile?.avatar_url || currentUser.avatar_url || './assets/avatar-default.svg';
}

function statusPill(value) {
  const normalized = String(value).toLowerCase();
  const cls = normalized.includes('aprob') || normalized.includes('activ') || normalized.includes('dispon') ? 'status-approved' : normalized.includes('pend') || normalized.includes('bajo') ? 'status-pending' : 'status-rejected';
  return `<span class="status-pill ${cls}">${value}</span>`;
}

function tableActions() {
  return `<div class="actions">
    <button class="action-btn" title="Ver">${icons.eye}</button>
    <button class="action-btn" title="Editar">${icons.edit}</button>
    <button class="action-btn" title="Eliminar">${icons.trash}</button>
  </div>`;
}

function card(title, body, extraClass = '') {
  return `<section class="card glass ${extraClass}">${body ? `<h3>${title}</h3>${body}` : title}</section>`;
}

function renderNav() {
  const items = navByRole[roleKey] || navByRole.administrator;
  const current = location.hash.replace('#', '') || 'dashboard';
  navMenu.innerHTML = items.map(([key, label]) => `
    <a href="#${key}" class="nav-item ${current === key ? 'active' : ''}">
      ${icons[key] || icons.dashboard}
      <span>${label}</span>
    </a>
  `).join('') + `
    <button id="logoutBtn" class="nav-item" style="border:0;background:transparent;cursor:pointer;">
      ${icons.logout}<span>Cerrar sesión</span>
    </button>`;

  document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    localStorage.removeItem('ism_demo_user');
    await window.sb.signOut();
    location.href = './index.html';
  });
}

function renderNotificationsPreview() {
  const notifications = demoState.notifications;
  const unread = notifications.filter(n => n.unread).length;
  notificationCount.textContent = unread;
  notificationsPreview.innerHTML = notifications.length ? notifications.slice(0, 4).map(n => `
    <article class="list-item">
      <strong>${n.title}</strong>
      <p class="muted">${n.message}</p>
    </article>
  `).join('') : '<div class="empty-state">Sin notificaciones.</div>';
}

function dashboardView() {
  pageTitle.textContent = 'Dashboard';
  pageSubtitle.textContent = 'Resumen ejecutivo del laboratorio';
  return `
    <section class="grid-cards">
      ${card('Usuarios', `<div class="kpi">148</div><p class="muted">Administradores, docentes y alumnos.</p>`)}
      ${card('Equipos', `<div class="kpi">24</div><p class="muted">Con seguimiento de asignación por docente.</p>`)}
      ${card('Inventario', `<div class="kpi">362</div><p class="muted">Ítems con control mínimo y movimientos.</p>`)}
      ${card('Notificaciones', `<div class="kpi">${demoState.notifications.filter(n => n.unread).length}</div><p class="muted">Pendientes de lectura.</p>`)}
    </section>

    <section class="layout-two">
      ${card('Accesos rápidos', `
        <div class="toolbar">
          <button class="btn btn-primary">Nuevo usuario</button>
          <button class="btn btn-secondary">Nuevo equipo</button>
          <button class="btn btn-secondary">Importar inventario</button>
          <button class="btn btn-secondary">Enviar aviso</button>
        </div>
      `)}
      ${card('Estado del sistema', `
        <div class="list-simple">
          <div class="metric-inline"><span>Supabase Auth</span>${statusPill(window.sb.enabled ? 'Conectado' : 'Demo')}</div>
          <div class="metric-inline"><span>PWA</span>${statusPill('Activa')}</div>
          <div class="metric-inline"><span>GitHub Pages</span>${statusPill('Listo')}</div>
        </div>
      `)}
    </section>

    <section class="inventory-grid">
      ${card('Inventario crítico', `
        <div class="list-simple">
          ${demoState.inventory.map(item => `
            <div class="list-item">
              <div class="metric-inline"><strong>${item.name}</strong>${statusPill(item.status)}</div>
              <p class="muted">Código ${item.code} · Categoría ${item.category}</p>
              <div class="progress"><span style="width:${Math.min((item.stock / Math.max(item.min_stock, 1)) * 50, 100)}%"></span></div>
            </div>
          `).join('')}
        </div>
      `)}
      ${card('Actividad reciente', `
        <div class="list-simple">
          <div class="list-item"><strong>Alta de alumno</strong><p class="muted">Se registró un nuevo alumno de 6°C.</p></div>
          <div class="list-item"><strong>Módulo publicado</strong><p class="muted">Docente María López subió “Electrónica aplicada”.</p></div>
          <div class="list-item"><strong>Movimiento de stock</strong><p class="muted">Se descontaron 2 sensores para RoboAlpha.</p></div>
        </div>
      `)}
    </section>`;
}

function usersView() {
  pageTitle.textContent = 'Usuarios y perfiles';
  pageSubtitle.textContent = 'ABM completo, roles, permisos y datos extendidos';
  return `
    <section class="card glass">
      <div class="section-header">
        <div>
          <h3>Administración de usuarios</h3>
          <p class="muted">Datos sugeridos: WhatsApp, fecha de nacimiento, DNI, curso/división o materia/título.</p>
        </div>
        <div class="toolbar">
          <button class="btn btn-primary">Nuevo usuario</button>
          <button class="btn btn-secondary">Exportar CSV</button>
        </div>
      </div>
      <div class="toolbar" style="margin:16px 0;">
        <input placeholder="Buscar por nombre, DNI, WhatsApp o email" />
        <select><option>Todos los roles</option><option>Administrador</option><option>Docente</option><option>Alumno</option></select>
        <select><option>Todos los estados</option><option>Activo</option><option>Pendiente</option></select>
      </div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Nombre</th><th>Rol</th><th>Email</th><th>WhatsApp</th><th>DNI</th><th>Estado</th><th>Acciones</th></tr></thead>
          <tbody>
            ${demoState.users.map(u => `<tr>
              <td><strong>${u.full_name}</strong></td>
              <td>${u.role}</td>
              <td>${u.email}</td>
              <td>${u.whatsapp}</td>
              <td>${u.dni}</td>
              <td>${statusPill(u.status)}</td>
              <td>${tableActions()}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </section>`;
}

function rolesView() {
  pageTitle.textContent = 'Roles y permisos';
  pageSubtitle.textContent = 'Control granular desde el perfil Administrador';
  return `
    <section class="settings-layout">
      ${card('Roles del sistema', `
        <div class="list-simple">
          <div class="list-item"><strong>Administrador</strong><p class="muted">Control total de perfiles, usuarios, inventario, biblioteca y configuración.</p></div>
          <div class="list-item"><strong>Docente</strong><p class="muted">Gestiona sus equipos, módulos, lecciones, tareas y evaluativos.</p></div>
          <div class="list-item"><strong>Alumno</strong><p class="muted">Accede a contenido, tareas, biblioteca y seguimiento de su equipo.</p></div>
        </div>
      `)}
      ${card('Permisos editables', `
        <div class="list-simple">
          <div class="list-item"><div class="metric-inline"><span>Gestionar usuarios</span>${statusPill('Habilitado')}</div></div>
          <div class="list-item"><div class="metric-inline"><span>Administrar inventario</span>${statusPill('Habilitado')}</div></div>
          <div class="list-item"><div class="metric-inline"><span>Biblioteca digital</span>${statusPill('Configurable')}</div></div>
          <div class="list-item"><div class="metric-inline"><span>Enviar notificaciones masivas</span>${statusPill('Habilitado')}</div></div>
        </div>
      `)}
    </section>`;
}

function teamView() {
  pageTitle.textContent = 'Equipos';
  pageSubtitle.textContent = roleKey === 'teacher' ? 'Equipos de alumnos asignados' : 'Gestión de equipos del laboratorio';
  return `
    <section class="card glass">
      <div class="section-header">
        <div><h3>Equipos</h3><p class="muted">Alta, asignación de docente, integrantes y seguimiento.</p></div>
        <div class="toolbar"><button class="btn btn-primary">Nuevo equipo</button></div>
      </div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Equipo</th><th>Líder</th><th>Docente</th><th>Miembros</th><th>Curso</th><th>Estado</th><th>Acciones</th></tr></thead>
          <tbody>${demoState.equipment.map(t => `<tr><td><strong>${t.name}</strong></td><td>${t.leader}</td><td>${t.teacher}</td><td>${t.members}</td><td>${t.course}</td><td>${statusPill(t.status)}</td><td>${tableActions()}</td></tr>`).join('')}</tbody>
        </table>
      </div>
    </section>`;
}

function inventoryView() {
  pageTitle.textContent = 'Inventario y equipos';
  pageSubtitle.textContent = 'Control de stock, categorías, préstamos y movimientos';
  return `
    <section class="inventory-grid">
      ${card('Resumen de inventario', `
        <div class="grid-cards" style="grid-template-columns:repeat(2,1fr);">
          ${card('Ítems', '<div class="kpi">362</div><p class="muted">Total cargado.</p>')}
          ${card('Bajo stock', '<div class="kpi">14</div><p class="muted">Requieren reposición.</p>')}
          ${card('Préstamos', '<div class="kpi">9</div><p class="muted">Actualmente asignados.</p>')}
          ${card('Movimientos hoy', '<div class="kpi">27</div><p class="muted">Entradas y salidas.</p>')}
        </div>
      `)}
      ${card('Importación / sincronización', `
        <div class="list-simple">
          <div class="list-item"><strong>Google Sheets</strong><p class="muted">Preparado para importación manual o ETL desde una planilla modelo.</p></div>
          <div class="list-item"><strong>CSV</strong><p class="muted">Compatible con exportación e importación administrativa.</p></div>
          <div class="list-item"><strong>Historial</strong><p class="muted">Toda operación queda registrada en movimientos de stock.</p></div>
        </div>
      `)}
    </section>
    <section class="card glass">
      <div class="section-header">
        <div><h3>Control de inventario</h3><p class="muted">Compatible con lectores manuales, códigos y observaciones.</p></div>
        <div class="toolbar"><button class="btn btn-primary">Nuevo ítem</button><button class="btn btn-secondary">Importar hoja</button></div>
      </div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>Stock</th><th>Mínimo</th><th>Estado</th><th>Acciones</th></tr></thead>
          <tbody>${demoState.inventory.map(i => `<tr><td>${i.code}</td><td><strong>${i.name}</strong></td><td>${i.category}</td><td>${i.stock}</td><td>${i.min_stock}</td><td>${statusPill(i.status)}</td><td>${tableActions()}</td></tr>`).join('')}</tbody>
        </table>
      </div>
    </section>`;
}

function coursesView() {
  pageTitle.textContent = roleKey === 'student' ? 'Mis módulos' : 'Campus docente';
  pageSubtitle.textContent = 'Módulos, lecciones, tareas y evaluativos estilo LearnPress';
  return `
    <section class="course-grid">
      ${card('Estructura pedagógica', `
        <div class="list-simple">
          <div class="list-item"><strong>Módulos</strong><p class="muted">Agrupan contenidos, lecciones, tareas y evaluaciones.</p></div>
          <div class="list-item"><strong>Lecciones</strong><p class="muted">Texto enriquecido, videos, adjuntos y recursos externos.</p></div>
          <div class="list-item"><strong>Tareas / Evaluativos</strong><p class="muted">Con fecha límite, rúbrica y calificación.</p></div>
        </div>
      `)}
      ${card('Acciones rápidas', `
        <div class="toolbar">
          <button class="btn btn-primary">Nuevo módulo</button>
          <button class="btn btn-secondary">Nueva lección</button>
          <button class="btn btn-secondary">Nuevo evaluativo</button>
        </div>
      `)}
    </section>
    <section class="card glass">
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Módulo</th><th>Lecciones</th><th>Tareas</th><th>Evaluativo</th><th>Público</th><th>Acciones</th></tr></thead>
          <tbody>${demoState.modules.map(m => `<tr><td><strong>${m.name}</strong></td><td>${m.lessons}</td><td>${m.tasks}</td><td>${m.evaluative}</td><td>${m.audience}</td><td>${tableActions()}</td></tr>`).join('')}</tbody>
        </table>
      </div>
    </section>`;
}

function libraryView() {
  pageTitle.textContent = 'Biblioteca digital';
  pageSubtitle.textContent = 'Repositorio de manuales, reglamentos y material de estudio';
  return `
    <section class="card glass">
      <div class="section-header">
        <div><h3>Recursos</h3><p class="muted">Subida de archivos, enlaces externos y permisos por rol.</p></div>
        <div class="toolbar"><button class="btn btn-primary">Subir recurso</button></div>
      </div>
      <div class="file-grid">
        ${demoState.library.map(file => `<article class="file-item glass"><strong>${file.title}</strong><p class="muted">${file.type}</p>${statusPill(file.access)}</article>`).join('')}
      </div>
    </section>`;
}

function notificationsView() {
  pageTitle.textContent = 'Notificaciones';
  pageSubtitle.textContent = 'Envío masivo, individual, por equipo o múltiple selección';
  return `
    <section class="layout-two">
      ${card('Enviar notificación', `
        <form class="form-grid">
          <label><span>Destino</span><select><option>Todos los usuarios</option><option>Individual</option><option>Equipo</option><option>Selección múltiple</option></select></label>
          <label><span>Título</span><input placeholder="Asunto de la notificación" /></label>
          <label><span>Mensaje</span><textarea rows="5" placeholder="Escribí el contenido"></textarea></label>
          <button class="btn btn-primary" type="button">Enviar</button>
        </form>
      `)}
      ${card('Bandeja', `
        <div class="list-simple">
          ${demoState.notifications.map(n => `<div class="list-item"><div class="metric-inline"><strong>${n.title}</strong>${statusPill(n.unread ? 'Sin leer' : 'Leída')}</div><p class="muted">${n.message}</p></div>`).join('')}
        </div>
      `)}
    </section>`;
}

function profileView() {
  pageTitle.textContent = 'Mi perfil';
  pageSubtitle.textContent = 'Consulta y edición de datos personales';
  return `
    <section class="profile-layout">
      ${card('Datos personales', `
        <div class="list-simple">
          <div class="list-item"><strong>Nombre</strong><p class="muted">${currentProfile?.full_name || currentUser.name || 'Admin General'}</p></div>
          <div class="list-item"><strong>Email</strong><p class="muted">${currentProfile?.email || currentUser.email || 'admin@ism.edu.ar'}</p></div>
          <div class="list-item"><strong>Rol</strong><p class="muted">${roleKey}</p></div>
          <div class="list-item"><strong>WhatsApp</strong><p class="muted">+54 9 11 5555 1111</p></div>
        </div>
      `)}
      ${card('Editar perfil', `
        <form class="form-grid">
          <label><span>Nombre completo</span><input value="${currentProfile?.full_name || currentUser.name || ''}" /></label>
          <label><span>DNI</span><input value="30111222" /></label>
          <label><span>Fecha de nacimiento</span><input type="date" value="1985-03-20" /></label>
          <label><span>WhatsApp</span><input value="+54 9 11 5555 1111" /></label>
          <label><span>Foto de perfil</span><input type="file" accept="image/*" /></label>
          <button class="btn btn-primary" type="button">Guardar cambios</button>
        </form>
      `)}
    </section>`;
}

function settingsView() {
  pageTitle.textContent = 'Configuraciones';
  pageSubtitle.textContent = 'Personalización del sistema, branding y parámetros globales';
  return `
    <section class="settings-layout">
      ${card('Sistema', `
        <form class="form-grid">
          <label><span>Nombre institucional</span><input value="Instituto San Miguel" /></label>
          <label><span>Logo institucional</span><input type="file" accept="image/*" /></label>
          <label><span>Color principal</span><input type="color" value="#78a6ff" /></label>
          <label><span>Zona horaria</span><select><option>America/Argentina/Buenos_Aires</option></select></label>
          <button class="btn btn-primary" type="button">Guardar configuración</button>
        </form>
      `)}
      ${card('Parámetros funcionales', `
        <div class="list-simple">
          <div class="list-item"><strong>Registro de alumnos</strong><p class="muted">Campos: curso, división, DNI, WhatsApp, fecha de nacimiento.</p></div>
          <div class="list-item"><strong>Registro docente</strong><p class="muted">Campos: materia, título, DNI, fecha de nacimiento.</p></div>
          <div class="list-item"><strong>Inventario</strong><p class="muted">Habilita movimientos, mínimos y préstamos.</p></div>
        </div>
      `)}
    </section>`;
}

const views = {
  dashboard: dashboardView,
  users: usersView,
  roles: rolesView,
  team: teamView,
  inventory: inventoryView,
  courses: coursesView,
  library: libraryView,
  notifications: notificationsView,
  profile: profileView,
  settings: settingsView,
};

function renderRoute() {
  const route = location.hash.replace('#', '') || 'dashboard';
  const view = views[route] || dashboardView;
  appContent.innerHTML = view();
  renderNav();
}

function applyTheme(theme) {
  document.body.classList.toggle('light', theme === 'light');
  localStorage.setItem('ism_theme', theme);
}

async function initProfile() {
  if (window.sb.enabled) {
    try {
      const profile = await window.sb.fetchProfile();
      if (profile) {
        currentProfile = profile;
        roleKey = profile.roles?.code || 'administrator';
      }
    } catch (e) {
      console.warn('No se pudo cargar el perfil', e);
    }
  }
  setHeaderUser();
}

document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  if (window.innerWidth <= 900) {
    appShell.classList.toggle('sidebar-open');
  } else {
    appShell.classList.toggle('collapsed');
  }
});

document.getElementById('themeToggle')?.addEventListener('click', () => {
  applyTheme(document.body.classList.contains('light') ? 'dark' : 'light');
});

document.getElementById('fullscreenBtn')?.addEventListener('click', async () => {
  if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
  else await document.exitFullscreen();
});

document.getElementById('profileQuickBtn')?.addEventListener('click', () => {
  location.hash = 'profile';
});

document.getElementById('notificationsBtn')?.addEventListener('click', () => {
  location.hash = 'notifications';
});

window.addEventListener('hashchange', renderRoute);
window.addEventListener('resize', () => {
  if (window.innerWidth > 900) appShell.classList.remove('sidebar-open');
});

applyTheme(localStorage.getItem('ism_theme') || 'dark');
renderNotificationsPreview();
initProfile().finally(renderRoute);
