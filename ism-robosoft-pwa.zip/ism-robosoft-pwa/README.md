# ISM Robosoft PWA

PWA responsive para la gestión administrativa del Laboratorio de Robótica del Instituto San Miguel.

## Incluye
- Login listo para GitHub Pages.
- Panel Administrador, Docente y Alumno.
- Sidebar colapsable al hacer clic en el logo.
- Header con toggle tema, fullscreen, notificaciones y acceso a perfil.
- Módulos base: usuarios, roles, equipos, inventario, campus docente, biblioteca, notificaciones, perfil y configuraciones.
- Service Worker y manifest para comportamiento PWA.
- Esquema SQL para Supabase con tablas, relaciones y RLS inicial.

## Estructura
- `index.html`: login.
- `app.html`: shell principal.
- `styles.css`: estilos responsive.
- `auth.js`: login y demo.
- `app.js`: navegación y vistas.
- `supabase.js`: helper de conexión.
- `config.example.js`: variables a completar.
- `sql/`: scripts para crear la base.

## Despliegue en GitHub Pages
1. Subí el contenido del proyecto a un repositorio.
2. En GitHub, activá Pages desde la rama principal.
3. Copiá `config.example.js` a `config.js` si querés separar secretos públicos de ejemplo, o editá directamente el archivo de config con tu URL y anon key de Supabase.
4. Ejecutá el SQL en Supabase.
5. Creá usuarios en Auth y sus perfiles en la tabla `profiles`.

## Notas
- El proyecto incluye modo demo si Supabase todavía no está configurado.
- Las operaciones CRUD reales están preparadas como base y deben conectarse a formularios/modales en la siguiente fase.
- Para importar una planilla de inventario, lo recomendable es usar una tabla staging o un flujo CSV/Sheet -> Edge Function -> tablas finales.
