# Fases sugeridas

## Fase 1
Base PWA, login, layout responsive, roles base, panel admin/docente/alumno, tema oscuro/claro, header, footer y navegación.

## Fase 2
ABM real con Supabase Auth + perfiles, carga de avatar, roles/permisos, notificaciones, inventario, equipos y biblioteca.

## Fase 3
Campus docente estilo LearnPress: módulos, lecciones, tareas, evaluativos, progreso y calificaciones.

## Fase 4
Automatizaciones: importación desde Google Sheets, reportes, exportaciones, bitácora de auditoría y métricas.

## Fase 5
Hardening final: RLS, pruebas, backup, accesibilidad, SEO básico de GitHub Pages y despliegue productivo.
