-- Fase de ajuste: equipos mixtos, múltiples docentes y mejoras operativas

create table if not exists public.team_teachers (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  teacher_profile_id uuid not null references public.profiles(id) on delete cascade,
  is_lead boolean not null default false,
  created_at timestamptz not null default now(),
  unique(team_id, teacher_profile_id)
);

create table if not exists public.team_course_divisions (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  course_label text not null,
  division_label text,
  created_at timestamptz not null default now()
);

alter table if exists public.notifications
  add column if not exists preview_text text,
  add column if not exists target_scope text default 'all',
  add column if not exists requires_ack boolean not null default false;

alter table if exists public.inventory_loans
  add column if not exists delivered_condition text,
  add column if not exists returned_condition text,
  add column if not exists delivered_by uuid references public.profiles(id) on delete set null,
  add column if not exists received_by uuid references public.profiles(id) on delete set null;

create index if not exists idx_team_teachers_team on public.team_teachers(team_id);
create index if not exists idx_team_teachers_teacher on public.team_teachers(teacher_profile_id);
create index if not exists idx_team_course_divisions_team on public.team_course_divisions(team_id);
