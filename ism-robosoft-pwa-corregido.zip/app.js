const icons = {
  dashboard: `<svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10Zm10 8h8V11h-8v10ZM3 21h8v-6H3v6Zm10-10h8V3h-8v8Z"></path></svg>`,
  users: `<svg viewBox="0 0 24 24"><path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4ZM8 12a3 3 0 1 0-3-3 3 3 0 0 0 3 3Zm8 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4ZM8 14c-.29 0-.62.02-.97.05C5.7 14.16 2 14.82 2 17v2h4v-1c0-1.46.8-2.68 2.29-3.64A9.79 9.79 0 0 0 8 14Z"></path></svg>`,
  roles: `<svg viewBox="0 0 24 24"><path d="m12 1 9 4v6c0 5.55-3.84 10.74-9 12-5.16-1.26-9-6.45-9-12V5l9-4Zm0 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm0 6c-1.83 0-3.8.93-4 2v1h8v-1c-.2-1.07-2.17-2-4-2Z"></path></svg>`,
  team: `<svg viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.79 2.99-4S17.66 3 16 3s-3 1.79-3 4 1.34 4 3 4Zm-8 0c1.66 0 2.99-1.79 2.99-4S9.66 3 8 3 5 4.79 5 7s1.34 4 3 4Zm0 2c-2.33 0-7 1.17-7 3.5V20h14v-3.5C15 14.17 10.33 13 8 13Zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.95 1.97 3.45V20h6v-3.5c0-2.33-4.67-3.5-7-3.5Z"></path></svg>`,
  inventory: `<svg viewBox="0 0 24 24"><path d="M21 16V8l-9-5-9 5v8l9 5 9-5Zm-9 2.7-6-3.33V9.3l6 3.33 6-3.33v6.07l-6 3.33Zm0-8.37L6.04 7 12 3.7 17.96 7 12 10.33Z"></path></svg>`,
  courses: `<svg viewBox="0 0 24 24"><path d="M12 3 1 9l11 6 9-4.91V17h2V9L12 3Zm-7 9.18V17l7 4 7-4v-4.82l-7 3.82-7-3.82Z"></path></svg>`,
  library: `<svg viewBox="0 0 24 24"><path d="M18 2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10v-2H8V4h10V2Zm-3 4h5a1 1 0 0 1 1 1v15l-3-2-3 2V7a1 1 0 0 1 1-1Z"></path></svg>`,
  notifications: `<svg viewBox="0 0 24 24"><path d="M12 22a2.5 2.5 0 0 0 2.45-2h-4.9A2.5 2.5 0 0 0 12 22Zm7-6V11a7 7 0 1 0-14 0v5L3 18v1h18v-1l-2-2Z"></path></svg>`,
  profile: `<svg viewBox="0 0 24 24"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4Z"></path></svg>`,
  settings: `<svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.6-.22l-2.39.96a7.16 7.16 0 0 0-1.63-.94l-.36-2.54a.49.49 0 0 0-.49-.42h-3.84a.49.49 0 0 0-.49.42l-.36 2.54c-.58.22-1.12.53-1.63.94l-2.39-.96a.5.5 0 0 0-.6.22L2.71 8.84a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94L2.83 14.52a.5.5 0 0 0-.12.64l1.92 3.32c.13.22.39.31.6.22l2.39-.96c.51.41 1.05.72 1.63.94l.36 2.54c.05.24.25.42.49.42h3.84c.24 0 .44-.18.49-.42l.36-2.54c.58-.22 1.12-.53 1.63-.94l2.39.96c.22.09.47 0 .6-.22l1.92-3.32a.5.5 0 0 0-.12-.64l-2.03-1.58ZM12 15.5A3.5 3.5 0 1 1 12 8a3.5 3.5 0 0 1 0 7.5Z"></path></svg>`,
  logout: `<svg viewBox="0 0 24 24"><path d="M10 17v-3H3v-4h7V7l5 5-5 5Zm4-14h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5v-2h5V5h-5V3Z"></path></svg>`,
  eye: `<svg viewBox="0 0 24 24"><path d="M12 5c5.05 0 9.27 3.11 11 7-1.73 3.89-5.95 7-11 7S2.73 15.89 1 12c1.73-3.89 5.95-7 11-7Zm0 2C8.36 7 5.17 9.06 3.33 12 5.17 14.94 8.36 17 12 17s6.83-2.06 8.67-5C18.83 9.06 15.64 7 12 7Zm0 2.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"></path></svg>`,
  edit: `<svg viewBox="0 0 24 24"><path d="m3 17.25 9.81-9.81 3.75 3.75L6.75 21H3v-3.75ZM14.87 5.38l1.77-1.77a1.5 1.5 0 0 1 2.12 0l1.63 1.63a1.5 1.5 0 0 1 0 2.12l-1.77 1.77-3.75-3.75Z"></path></svg>`,
  trash: `<svg viewBox="0 0 24 24"><path d="M6 7h12l-1 14H7L6 7Zm3-4h6l1 2h4v2H4V5h4l1-2Z"></path></svg>`,
  barcode: `<svg viewBox="0 0 24 24"><path d="M4 5h1v14H4V5Zm3 0h2v14H7V5Zm4 0h1v14h-1V5Zm3 0h3v14h-3V5Zm5 0h1v14h-1V5Z"></path></svg>`,
  upload: `<svg viewBox="0 0 24 24"><path d="M12 3 7 8h3v6h4V8h3l-5-5Zm-7 14h14v4H5v-4Z"></path></svg>`,
  download: `<svg viewBox="0 0 24 24"><path d="M12 16 7 11h3V4h4v7h3l-5 5Zm-7 2h14v2H5v-2Z"></path></svg>`,
  bell: `<svg viewBox="0 0 24 24"><path d="M12 22a2.5 2.5 0 0 0 2.45-2h-4.9A2.5 2.5 0 0 0 12 22Zm7-6V11a7 7 0 1 0-14 0v5L3 18v1h18v-1l-2-2Z"></path></svg>`,
  expand: `<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  sun: `<svg viewBox="0 0 24 24"><path d="M12 4.5a1 1 0 0 1 1 1V7a1 1 0 1 1-2 0V5.5a1 1 0 0 1 1-1Zm0 12a1 1 0 0 1 1 1V19a1 1 0 1 1-2 0v-1.5a1 1 0 0 1 1-1Zm7.5-5.5a1 1 0 1 1 0 2H18a1 1 0 1 1 0-2h1.5ZM6 12a1 1 0 0 1-1 1H3.5a1 1 0 1 1 0-2H5a1 1 0 0 1 1 1Zm10.95-5.536a1 1 0 0 1 1.414 0l.707.707a1 1 0 1 1-1.414 1.414l-.707-.707a1 1 0 0 1 0-1.414ZM6.05 16.95a1 1 0 0 1 1.414 0l.707.707a1 1 0 1 1-1.414 1.414l-.707-.707a1 1 0 0 1 0-1.414Zm0-9.9a1 1 0 0 1 0 1.414l-.707.707A1 1 0 0 1 3.93 7.757l.707-.707a1 1 0 0 1 1.414 0Zm10.607 10.607a1 1 0 0 1 0 1.414l-.707.707a1 1 0 0 1-1.414-1.414l.707-.707a1 1 0 0 1 1.414 0ZM12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z"></path></svg>`,
  moon: `<svg viewBox="0 0 24 24"><path d="M14.53 3.47A8.5 8.5 0 1 0 20.53 18 7 7 0 0 1 14.53 3.47Z"></path></svg>`
};

const demoState = {
  notifications: [
    { id: 1, title: 'Préstamo vencido', message: 'El kit AR000311 debía devolverse hoy a las 16:00.', unread: true, target: 'Inventario', route: 'inventory' },
    { id: 2, title: 'Ingreso de inventario', message: 'Se registraron 6 sensores ultrasónicos nuevos.', unread: true, target: 'Inventario', route: 'inventory' },
    { id: 3, title: 'Módulo actualizado', message: 'Electrónica aplicada tiene evaluativo publicado.', unread: false, target: 'Campus docente', route: 'courses' },
    { id: 4, title: 'Equipo mixto asignado', message: 'RoboMixto 2026 ahora tiene 2 docentes responsables y alumnos de 5°A y 6°C.', unread: true, target: 'Equipos', route: 'team' }
  ],
  users: [
    { full_name: 'Fernando Gambino', role: 'Administrador', email: 'fgambino@ism.edu.ar', whatsapp: '+54 9 11 5555 1111', dni: '30111222', status: 'Activo' },
    { full_name: 'María López', role: 'Docente', email: 'mlopez@ism.edu.ar', whatsapp: '+54 9 11 4444 2222', dni: '28999888', status: 'Activo' },
    { full_name: 'Thiago Benjamín Luna', role: 'Alumno', email: 'thiago.luna@ism.edu.ar', whatsapp: '+54 9 11 3333 1111', dni: '49442589', status: 'Pendiente' },
    { full_name: 'Sofía Ramírez', role: 'Docente', email: 'sramirez@ism.edu.ar', whatsapp: '+54 9 11 2222 4444', dni: '27666111', status: 'Activo' }
  ],
  teams: [
    { name: 'RoboAlpha', leaders: 'Thiago Luna', teachers: 'María López', members: 4, courses: '6°C', status: 'Activo' },
    { name: 'MechBots', leaders: 'Tomás Cáceres', teachers: 'María López', members: 5, courses: '5°A', status: 'Activo' },
    { name: 'RoboMixto 2026', leaders: 'Julián Pérez', teachers: 'María López · Sofía Ramírez', members: 7, courses: '5°A · 6°C', status: 'Activo' }
  ],
  modules: [
    { name: 'Introducción a la robótica', lessons: 5, tasks: 3, evaluative: 'Sí', audience: 'Alumnos 1er tramo', completion: 72 },
    { name: 'Electrónica aplicada', lessons: 7, tasks: 4, evaluative: 'Sí', audience: 'Alumnos avanzados', completion: 54 },
    { name: 'Programación de sensores', lessons: 4, tasks: 2, evaluative: 'No', audience: '5° y 6°', completion: 80 }
  ],
  library: [
    { title: 'Manual de Arduino', type: 'PDF', access: 'Docentes y Alumnos' },
    { title: 'Reglamento de laboratorio', type: 'PDF', access: 'Todos' },
    { title: 'Catálogo de sensores 2026', type: 'Drive / Link', access: 'Administradores' }
  ],
  inventoryCatalog: [
    { asset_code: 'AR000322', barcode: '8435439883658', description: 'Kit Prog. de las Cosas', brand: 'SetVeintiUno', category: 'Kit de Robótica', serial: 'SVU-KIT-322', stock_type: 'serializado', status: 'USADO / COMPLETO', location: 'Armario A1', assigned_to: 'Disponible', due_back: '—' },
    { asset_code: 'AR000311', barcode: '9435339883658', description: 'Kit Prog. de las Cosas', brand: 'SetVeintiUno', category: 'Kit de Robótica', serial: 'SVU-KIT-311', stock_type: 'serializado', status: 'DAÑADO / FALTA PIEZAS', location: 'Mesa técnica', assigned_to: 'Taller de revisión', due_back: '—' },
    { asset_code: 'AR000362', barcode: '8435439883659', description: 'Kit Prog. de las Cosas', brand: 'SetVeintiUno', category: 'Kit de Robótica', serial: 'SVU-KIT-362', stock_type: 'serializado', status: 'NUEVO', location: 'Depósito', assigned_to: 'Disponible', due_back: '—' },
    { asset_code: 'SM-USB-001', barcode: 'ISMROB-USB-000001', description: 'Cable USB para kit', brand: 'RobotGroup', category: 'Componentes', serial: '', stock_type: 'consumible', status: 'NUEVO', location: 'Gaveta C4', assigned_to: 'Stock', due_back: '—' },
    { asset_code: 'SEN-HCSR04-02', barcode: 'ISMROB-SEN-000002', description: 'Sensor ultrasónico HC-SR04', brand: 'RobotGroup', category: 'Componentes', serial: 'HCSR04-7781', stock_type: 'serializado', status: 'EN PRÉSTAMO', location: 'Aula 6°C', assigned_to: 'Prof. María López', due_back: '18/04/2026 12:00' }
  ],
  inventoryLoans: [
    { code: 'PREST-00021', asset_code: 'SEN-HCSR04-02', item: 'Sensor ultrasónico HC-SR04', requester: 'Prof. María López', team: 'RoboAlpha', requested_at: '14/04/2026 08:10', status_out: 'Operativo / completo', status_in: 'Pendiente', returned_at: '—', due_at: '18/04/2026 12:00' },
    { code: 'PREST-00022', asset_code: 'AR000322', item: 'Kit Prog. de las Cosas', requester: 'Tomás Cáceres', team: 'MechBots', requested_at: '12/04/2026 10:45', status_out: 'Usado / completo', status_in: 'Usado / completo', returned_at: '13/04/2026 14:20', due_at: '13/04/2026 12:00' },
    { code: 'PREST-00023', asset_code: 'SM-USB-001', item: 'Cable USB para kit', requester: 'Prof. Sofía Ramírez', team: 'RoboMixto 2026', requested_at: '15/04/2026 09:30', status_out: 'Nuevo / operativo', status_in: 'Pendiente', returned_at: '—', due_at: '17/04/2026 17:30' }
  ]
};

const navByRole = {
  administrator: [['dashboard','Dashboard'],['users','Usuarios'],['roles','Roles y permisos'],['team','Equipos'],['inventory','Inventario'],['courses','Campus docente'],['library','Biblioteca digital'],['notifications','Notificaciones'],['profile','Mi perfil'],['settings','Configuraciones']],
  teacher: [['dashboard','Dashboard'],['team','Equipos asignados'],['inventory','Inventario'],['courses','Módulos y tareas'],['library','Biblioteca digital'],['notifications','Notificaciones'],['profile','Mi perfil']],
  student: [['dashboard','Dashboard'],['courses','Mis módulos'],['library','Biblioteca digital'],['notifications','Notificaciones'],['profile','Mi perfil']]
};

const roleLabels = { administrator: 'Administrador General', teacher: 'Docente', student: 'Alumno' };
const pageTitle = document.getElementById('pageTitle');
const pageSubtitle = document.getElementById('pageSubtitle');
const appContent = document.getElementById('appContent');
const navMenu = document.getElementById('navMenu');
const appShell = document.getElementById('appShell');
const notificationCount = document.getElementById('notificationCount');
const notificationsPreview = document.getElementById('notificationsPreview');
const headerUserName = document.getElementById('headerUserName');
const headerAvatar = document.getElementById('headerAvatar');
const avatarInput = document.getElementById('avatarInput');
const themeToggle = document.getElementById('themeToggle');
const notificationsWrapper = document.getElementById('notificationsWrapper');
let charts = [];
let currentProfile = null;
let selectedNotificationId = Number(localStorage.getItem('ism_selected_notification') || 0);
let roleKey = JSON.parse(localStorage.getItem('ism_demo_user') || '{}').role || 'administrator';
const currentUser = JSON.parse(localStorage.getItem('ism_demo_user') || '{}') || { name: 'Administrador General', email: 'admin@ism.edu.ar', avatar_url: './assets/avatar-default.svg', role: roleKey };

function escapeHtml(value) {
  return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

function statusPill(status) {
  const key = String(status).toLowerCase();
  let cls = 'status-neutral';
  if (/(activo|aprobado|completo|operativo|sí|leída|devuelto|nuevo)/.test(key)) cls = 'status-approved';
  else if (/(pendiente|préstamo|revision|revisión|en curso|sin leer)/.test(key)) cls = 'status-pending';
  else if (/(rechazado|dañado|eliminar|vencido|falta)/.test(key)) cls = 'status-rejected';
  return `<span class="status-pill ${cls}">${escapeHtml(status)}</span>`;
}

function card(title, body, extra = '') {
  return `<section class="panel-card">${title ? `<div class="panel-head"><div><h3>${escapeHtml(title)}</h3>${extra ? `<p class="muted">${extra}</p>` : ''}</div></div>` : ''}<div class="panel-body">${body}</div></section>`;
}

function tableActions(module = 'registro') {
  return `<div class="actions"><button class="action-btn" data-action="view" data-module="${module}" title="Ver">${icons.eye}</button><button class="action-btn" data-action="edit" data-module="${module}" title="Editar">${icons.edit}</button><button class="action-btn" data-action="delete" data-module="${module}" title="Eliminar">${icons.trash}</button></div>`;
}

function renderNav() {
  const current = location.hash.replace('#','') || 'dashboard';
  navMenu.innerHTML = `${navByRole[roleKey].map(([route, label]) => `<a class="nav-item ${current === route ? 'active' : ''}" href="#${route}">${icons[route]}<span>${label}</span></a>`).join('')}<button class="nav-item nav-logout" id="sidebarLogoutBtn">${icons.logout}<span>Cerrar sesión</span></button>`;
  document.getElementById('sidebarLogoutBtn')?.addEventListener('click', logout);
}

function setHeaderIcons() {
  document.getElementById('fullscreenBtn').innerHTML = icons.expand;
  document.getElementById('notificationsBtn').innerHTML = `${icons.bell}<span class="badge-dot" id="notificationCount">0</span>`;
  document.getElementById('logoutHeaderBtn').innerHTML = icons.logout;
  document.querySelector('.theme-icons').innerHTML = `${icons.sun}${icons.moon}`;
}

function updateNotificationPreview() {
  const unread = demoState.notifications.filter(n => n.unread).length;
  document.getElementById('notificationCount').textContent = unread;
  notificationsPreview.innerHTML = `<div class="preview-head"><strong>Notificaciones</strong><button class="preview-link" id="seeAllNotificationsBtn" type="button">Ver todas</button></div>${demoState.notifications.map(item => `<button class="notification-item ${item.unread ? 'unread' : ''}" data-id="${item.id}" data-route="${item.route}" type="button"><div class="metric-inline"><strong>${escapeHtml(item.title)}</strong>${statusPill(item.unread ? 'Sin leer' : 'Leída')}</div><p>${escapeHtml(item.message)}</p><small>${escapeHtml(item.target)}</small></button>`).join('')}`;
  notificationsPreview.querySelectorAll('.notification-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = Number(btn.dataset.id);
      selectedNotificationId = id;
      localStorage.setItem('ism_selected_notification', String(id));
      const notification = demoState.notifications.find(n => n.id === id);
      if (notification) notification.unread = false;
      notificationsWrapper.classList.remove('open');
      location.hash = '#notifications';
      updateNotificationPreview();
    });
  });
  document.getElementById('seeAllNotificationsBtn')?.addEventListener('click', () => {
    notificationsWrapper.classList.remove('open');
    location.hash = '#notifications';
  });
}

function setHeaderUser() {
  headerUserName.textContent = currentProfile?.full_name || currentUser.name || roleLabels[roleKey];
  headerAvatar.src = localStorage.getItem('ism_avatar_url') || currentProfile?.avatar_url || currentUser.avatar_url || './assets/avatar-default.svg';
}

function exportToCSV(filename, rows) {
  if (!rows?.length) return;
  const headers = Object.keys(rows[0]);
  const csv = [headers.join(',')].concat(rows.map(row => headers.map(h => `"${String(row[h] ?? '').replaceAll('"', '""')}"`).join(','))).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function parseCSV(text) {
  const [headerLine, ...lines] = text.trim().split(/\r?\n/);
  const headers = headerLine.split(',').map(h => h.replace(/^"|"$/g, '').trim());
  return lines.filter(Boolean).map(line => {
    const cols = line.match(/("([^"]|"")*"|[^,]+)/g) || [];
    const out = {};
    headers.forEach((h, i) => out[h] = String(cols[i] || '').replace(/^"|"$/g, '').replaceAll('""', '"'));
    return out;
  });
}

function sweetInfo(title, text, icon = 'success') {
  Swal.fire({ title, text, icon, confirmButtonText: 'Aceptar', confirmButtonColor: '#5568ff', background: getComputedStyle(document.body).getPropertyValue('--surface-solid') });
}

function genericActionHandler(e) {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const action = btn.dataset.action;
  const module = btn.dataset.module;
  if (action === 'delete') {
    Swal.fire({ title: '¿Eliminar registro?', text: `Se eliminará el elemento seleccionado del módulo ${module}.`, icon: 'warning', showCancelButton: true, confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar', confirmButtonColor: '#ef4444' }).then(r => {
      if (r.isConfirmed) sweetInfo('Registro eliminado', 'La acción fue simulada en esta demo.');
    });
    return;
  }
  sweetInfo(action === 'view' ? 'Vista rápida' : 'Edición', `Acción ${action} disponible en el módulo ${module}.`);
}

function kpiGrid(items) {
  return `<section class="kpi-grid">${items.map(item => `<article class="kpi-card"><span>${escapeHtml(item.label)}</span><strong>${escapeHtml(item.value)}</strong><small>${escapeHtml(item.hint || '')}</small></article>`).join('')}</section>`;
}

function filterBar(config = {}) {
  return `<div class="filter-bar">${(config.selects || []).map(select => `<label><span>${select.label}</span><select>${select.options.map(opt => `<option>${escapeHtml(opt)}</option>`).join('')}</select></label>`).join('')}<label class="grow"><span>${config.searchLabel || 'Buscar'}</span><input placeholder="${escapeHtml(config.searchPlaceholder || 'Buscar')}" /></label>${config.actions || ''}</div>`;
}

function dashboardView() {
  pageTitle.textContent = roleKey === 'administrator' ? 'Dashboard principal' : roleKey === 'teacher' ? 'Panel docente' : 'Panel alumno';
  pageSubtitle.textContent = roleKey === 'administrator' ? 'Resumen ejecutivo, métricas, alertas y filtros de gestión' : roleKey === 'teacher' ? 'Seguimiento de equipos, préstamos y módulos asignados' : 'Tus módulos, tareas y notificaciones';

  const roleSwitcher = `<div class="role-switcher">${['administrator','teacher','student'].map(role => `<button class="chip-btn ${roleKey === role ? 'active' : ''}" data-role="${role}">${roleLabels[role]}</button>`).join('')}</div>`;

  const kpis = roleKey === 'administrator'
    ? [
      { label: 'Usuarios', value: demoState.users.length, hint: 'ABM completo con roles y permisos' },
      { label: 'Equipos', value: demoState.teams.length, hint: 'Conformación simple y mixta' },
      { label: 'Activos trazables', value: demoState.inventoryCatalog.length, hint: 'Con serie o código de barras' },
      { label: 'Préstamos abiertos', value: demoState.inventoryLoans.filter(i => i.returned_at === '—').length, hint: 'Requieren seguimiento' }
    ]
    : roleKey === 'teacher'
    ? [
      { label: 'Equipos a cargo', value: 3, hint: 'Incluye equipos mixtos' },
      { label: 'Módulos publicados', value: 3, hint: 'Con tareas y evaluativos' },
      { label: 'Solicitudes abiertas', value: 2, hint: 'Pendientes de devolución' },
      { label: 'Notificaciones', value: demoState.notifications.filter(n => n.unread).length, hint: 'Sin leer' }
    ]
    : [
      { label: 'Módulos activos', value: 3, hint: 'Progreso en curso' },
      { label: 'Tareas pendientes', value: 4, hint: '2 vencen esta semana' },
      { label: 'Evaluativos', value: 2, hint: 'Publicados' },
      { label: 'Notificaciones', value: demoState.notifications.filter(n => n.unread).length, hint: 'Sin leer' }
    ];

  return `${card('', `${roleSwitcher}${kpiGrid(kpis)}`)}
  <section class="dashboard-grid">
    ${card('Resumen estadístico', `<div class="chart-toolbar"><span class="muted">Filtros rápidos</span><div class="chip-row"><button class="chip-btn active">Mensual</button><button class="chip-btn">Trimestral</button><button class="chip-btn">Anual</button></div></div><div class="chart-box"><canvas id="dashboardBarChart"></canvas></div>`)}
    ${card('Distribución por módulo', `<div class="chart-box"><canvas id="dashboardDonutChart"></canvas></div>`)}
  </section>
  <section class="dashboard-grid stretch">
    ${card('Tendencia operativa', `<div class="chart-box"><canvas id="dashboardLineChart"></canvas></div>`)}
    ${card('Alertas y actividad reciente', `<div class="list-simple">${demoState.notifications.slice(0,3).map(n => `<div class="list-item ${n.unread ? 'is-highlight' : ''}"><div class="metric-inline"><strong>${escapeHtml(n.title)}</strong>${statusPill(n.unread ? 'Sin leer' : 'Leída')}</div><p class="muted">${escapeHtml(n.message)}</p></div>`).join('')}</div>`)}
  </section>`;
}

function usersView() {
  pageTitle.textContent = 'Usuarios';
  pageSubtitle.textContent = 'ABM, roles, perfiles extendidos e importación/exportación CSV';
  return `${card('', `${filterBar({ selects: [{ label: 'Rol', options: ['Todos','Administrador','Docente','Alumno'] }, { label: 'Estado', options: ['Todos','Activo','Pendiente'] }], searchPlaceholder: 'Nombre, email, DNI o WhatsApp', actions: `<button class="btn btn-secondary" data-export="users">${icons.download} Exportar CSV</button><label class="btn btn-primary upload-btn">${icons.upload} Importar CSV<input type="file" accept=".csv" data-import="users" hidden></label><button class="btn btn-primary">Nuevo usuario</button>` })}
  <div class="table-wrap"><table class="table"><thead><tr><th>Nombre</th><th>Rol</th><th>Email</th><th>WhatsApp</th><th>DNI</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${demoState.users.map(user => `<tr><td><strong>${escapeHtml(user.full_name)}</strong></td><td>${escapeHtml(user.role)}</td><td>${escapeHtml(user.email)}</td><td>${escapeHtml(user.whatsapp)}</td><td>${escapeHtml(user.dni)}</td><td>${statusPill(user.status)}</td><td>${tableActions('usuarios')}</td></tr>`).join('')}</tbody></table></div>`)}
  <section class="dashboard-grid">${card('Altas por rol', `<div class="chart-box small"><canvas id="usersRoleChart"></canvas></div>`)}${card('Estado de usuarios', `<div class="chart-box small"><canvas id="usersStatusChart"></canvas></div>`)}</section>`;
}

function rolesView() {
  pageTitle.textContent = 'Roles y permisos';
  pageSubtitle.textContent = 'Administración granular de perfiles y permisos por módulo';
  return `<section class="dashboard-grid stretch">${card('Perfiles del sistema', `<div class="list-simple"><div class="list-item"><strong>Administrador</strong><p class="muted">Administra todos los módulos, usuarios, inventario, biblioteca, campus y configuraciones.</p></div><div class="list-item"><strong>Docente</strong><p class="muted">Gestiona módulos, tareas, préstamos y equipos asignados, incluyendo equipos mixtos con múltiples docentes.</p></div><div class="list-item"><strong>Alumno</strong><p class="muted">Accede a módulos, recursos, notificaciones y estado de sus actividades.</p></div></div>`)}${card('Matriz de permisos', `<div class="table-wrap"><table class="table"><thead><tr><th>Módulo</th><th>Administrador</th><th>Docente</th><th>Alumno</th></tr></thead><tbody><tr><td>Usuarios</td><td>${statusPill('Total')}</td><td>${statusPill('No')}</td><td>${statusPill('No')}</td></tr><tr><td>Inventario</td><td>${statusPill('Total')}</td><td>${statusPill('Solicitar / Devolver')}</td><td>${statusPill('Consulta')}</td></tr><tr><td>Campus</td><td>${statusPill('Supervisar')}</td><td>${statusPill('Crear / Editar')}</td><td>${statusPill('Consumir')}</td></tr><tr><td>Equipos</td><td>${statusPill('Total')}</td><td>${statusPill('Administrar asignados')}</td><td>${statusPill('Ver')}</td></tr></tbody></table></div>`)}</section>`;
}

function teamView() {
  pageTitle.textContent = roleKey === 'teacher' ? 'Equipos asignados' : 'Equipos';
  pageSubtitle.textContent = 'Equipos simples o mixtos con uno o varios docentes y alumnos de distintos cursos/divisiones';
  return `${card('', `${filterBar({ selects: [{ label: 'Curso / División', options: ['Todos','5°A','6°C','Mixto'] }, { label: 'Docente', options: ['Todos','María López','Sofía Ramírez'] }], searchPlaceholder: 'Buscar equipo o integrante', actions: `<button class="btn btn-secondary" data-export="teams">${icons.download} Exportar CSV</button><label class="btn btn-primary upload-btn">${icons.upload} Importar CSV<input type="file" accept=".csv" data-import="teams" hidden></label><button class="btn btn-primary">Nuevo equipo</button>` })}
  <div class="table-wrap"><table class="table"><thead><tr><th>Equipo</th><th>Líder</th><th>Docentes a cargo</th><th>Integrantes</th><th>Cursos / Divisiones</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${demoState.teams.map(t => `<tr><td><strong>${escapeHtml(t.name)}</strong></td><td>${escapeHtml(t.leaders)}</td><td>${escapeHtml(t.teachers)}</td><td>${escapeHtml(t.members)}</td><td>${escapeHtml(t.courses)}</td><td>${statusPill(t.status)}</td><td>${tableActions('equipos')}</td></tr>`).join('')}</tbody></table></div>`)}
  <section class="dashboard-grid">${card('Distribución de equipos', `<div class="chart-box small"><canvas id="teamsChart"></canvas></div>`)}${card('Observación funcional', `<div class="list-item is-highlight"><strong>Modelo mixto contemplado</strong><p class="muted">El sistema ya considera más de un docente por equipo y combinaciones entre cursos y divisiones distintas.</p></div>`)}</section>`;
}

function inventoryView() {
  pageTitle.textContent = 'Inventario';
  pageSubtitle.textContent = 'Trazabilidad completa de insumos, préstamos, devoluciones, estados y códigos de barras';
  return `${card('', `${kpiGrid([{ label: 'Items totales', value: demoState.inventoryCatalog.length, hint: 'Entre serializados y consumibles' }, { label: 'Préstamos activos', value: demoState.inventoryLoans.filter(i => i.returned_at === '—').length, hint: 'Con fecha de devolución' }, { label: 'Sin serie', value: demoState.inventoryCatalog.filter(i => !i.serial).length, hint: 'Con barcode interno' }, { label: 'Alertas', value: 2, hint: 'Revisión y faltantes' }])}`)}
  ${card('Catálogo y control', `${filterBar({ selects: [{ label: 'Tipo', options: ['Todos','serializado','consumible'] }, { label: 'Estado', options: ['Todos','NUEVO','EN PRÉSTAMO','DAÑADO / FALTA PIEZAS'] }, { label: 'Ubicación', options: ['Todas','Depósito','Armario A1','Mesa técnica','Aula 6°C'] }], searchPlaceholder: 'Código, barcode, descripción o serie', actions: `<button class="btn btn-secondary" data-export="inventory">${icons.download} Exportar CSV</button><label class="btn btn-primary upload-btn">${icons.upload} Importar CSV<input type="file" accept=".csv" data-import="inventory" hidden></label><button class="btn btn-primary">Nuevo insumo</button>` })}<div class="table-wrap"><table class="table inventory-table"><thead><tr><th>Código</th><th>Barcode</th><th>Descripción</th><th>Marca</th><th>Categoría</th><th>N° Serie</th><th>Tipo</th><th>Estado</th><th>Ubicación</th><th>Asignado a</th><th>Devuelve</th><th>Acciones</th></tr></thead><tbody>${demoState.inventoryCatalog.map(item => `<tr><td><strong>${escapeHtml(item.asset_code)}</strong></td><td><div class="barcode-cell"><span>${escapeHtml(item.barcode)}</span><span class="mini-icon">${icons.barcode}</span></div></td><td>${escapeHtml(item.description)}</td><td>${escapeHtml(item.brand)}</td><td>${escapeHtml(item.category)}</td><td>${item.serial ? escapeHtml(item.serial) : '<span class="muted">Sin serie · genera barcode</span>'}</td><td>${statusPill(item.stock_type)}</td><td>${statusPill(item.status)}</td><td>${escapeHtml(item.location)}</td><td>${escapeHtml(item.assigned_to)}</td><td>${escapeHtml(item.due_back)}</td><td>${tableActions('inventario')}</td></tr>`).join('')}</tbody></table></div>`)}
  <section class="dashboard-grid stretch">
    ${card('Préstamos y devoluciones', `<div class="table-wrap"><table class="table"><thead><tr><th>Código</th><th>Activo</th><th>Solicitante</th><th>Equipo</th><th>Salida</th><th>Estado de salida</th><th>Debe volver</th><th>Estado de devolución</th><th>Fecha devolución</th></tr></thead><tbody>${demoState.inventoryLoans.map(loan => `<tr><td><strong>${escapeHtml(loan.code)}</strong><div class="muted small">${escapeHtml(loan.asset_code)}</div></td><td>${escapeHtml(loan.item)}</td><td>${escapeHtml(loan.requester)}</td><td>${escapeHtml(loan.team)}</td><td>${escapeHtml(loan.requested_at)}</td><td>${statusPill(loan.status_out)}</td><td>${escapeHtml(loan.due_at)}</td><td>${statusPill(loan.status_in)}</td><td>${escapeHtml(loan.returned_at)}</td></tr>`).join('')}</tbody></table></div>`)}
    ${card('Barcode automático', `<div class="barcode-preview"><strong>Generación para insumos sin serie</strong><div class="barcode-lines"></div><span>ISMROB-USB-000001</span><p class="muted">Cuando no existe número de serie, el sistema emite un identificador interno trazable y listo para impresión.</p></div>`)}
  </section>
  <section class="dashboard-grid">${card('Movimientos por estado', `<div class="chart-box small"><canvas id="inventoryBarChart"></canvas></div>`)}${card('Préstamos vs devoluciones', `<div class="chart-box small"><canvas id="inventoryLineChart"></canvas></div>`)}</section>`;
}

function coursesView() {
  pageTitle.textContent = roleKey === 'student' ? 'Mis módulos' : 'Campus docente';
  pageSubtitle.textContent = 'Módulos, lecciones, tareas y evaluativos al estilo LearnPress';
  return `${card('', `${filterBar({ selects: [{ label: 'Estado', options: ['Todos','Publicado','Borrador'] }, { label: 'Público', options: ['Todos','5° y 6°','Alumnos avanzados'] }], searchPlaceholder: 'Buscar módulo o lección', actions: `<button class="btn btn-secondary" data-export="courses">${icons.download} Exportar CSV</button><label class="btn btn-primary upload-btn">${icons.upload} Importar CSV<input type="file" accept=".csv" data-import="courses" hidden></label>${roleKey === 'student' ? '' : '<button class="btn btn-primary">Nuevo módulo</button>'}` })}
  <div class="table-wrap"><table class="table"><thead><tr><th>Módulo</th><th>Lecciones</th><th>Tareas</th><th>Evaluativo</th><th>Público</th><th>Progreso</th><th>Acciones</th></tr></thead><tbody>${demoState.modules.map(m => `<tr><td><strong>${escapeHtml(m.name)}</strong></td><td>${m.lessons}</td><td>${m.tasks}</td><td>${m.evaluative}</td><td>${escapeHtml(m.audience)}</td><td><div class="progress"><span style="width:${m.completion}%"></span></div><small class="muted">${m.completion}%</small></td><td>${tableActions('campus')}</td></tr>`).join('')}</tbody></table></div>`)}
  <section class="dashboard-grid">${card('Avance por módulo', `<div class="chart-box small"><canvas id="coursesChart"></canvas></div>`)}${card('Resumen del panel', `<div class="list-item is-highlight"><strong>${roleKey === 'student' ? 'Demo Alumno' : 'Demo Docente'}</strong><p class="muted">${roleKey === 'student' ? 'Este panel muestra progreso, tareas y biblioteca del alumno.' : 'Este panel muestra carga de módulos, lecciones, tareas y evaluativos del docente.'}</p></div>`)}</section>`;
}

function libraryView() {
  pageTitle.textContent = 'Biblioteca digital';
  pageSubtitle.textContent = 'Repositorio de manuales, reglamentos y recursos de aprendizaje';
  return `${card('', `${filterBar({ selects: [{ label: 'Tipo', options: ['Todos','PDF','Drive / Link'] }, { label: 'Acceso', options: ['Todos','Todos','Docentes y Alumnos','Administradores'] }], searchPlaceholder: 'Buscar recurso', actions: `<button class="btn btn-secondary" data-export="library">${icons.download} Exportar CSV</button><label class="btn btn-primary upload-btn">${icons.upload} Importar CSV<input type="file" accept=".csv" data-import="library" hidden></label><button class="btn btn-primary">Subir recurso</button>` })}
  <div class="file-grid">${demoState.library.map(file => `<article class="file-item"><strong>${escapeHtml(file.title)}</strong><p class="muted">${escapeHtml(file.type)}</p>${statusPill(file.access)}</article>`).join('')}</div>`)}
`;
}

function notificationsView() {
  pageTitle.textContent = 'Notificaciones';
  pageSubtitle.textContent = 'Envío masivo, individual, por equipo o selección múltiple';
  return `<section class="dashboard-grid stretch">
    ${card('Enviar notificación', `<form class="form-grid"><label><span>Destino</span><select><option>Todos los usuarios</option><option>Individual</option><option>Equipo</option><option>Selección múltiple</option></select></label><label><span>Título</span><input placeholder="Asunto de la notificación" /></label><label class="full-span"><span>Mensaje</span><textarea rows="5" placeholder="Escribí el contenido"></textarea></label><button class="btn btn-primary" type="button" id="sendNotificationBtn">Enviar con SweetAlert2</button></form>`)}
    ${card('Bandeja', `<div class="list-simple">${demoState.notifications.map(n => `<button class="list-item notification-detail ${selectedNotificationId === n.id ? 'is-highlight' : ''}" data-id="${n.id}" type="button"><div class="metric-inline"><strong>${escapeHtml(n.title)}</strong>${statusPill(n.unread ? 'Sin leer' : 'Leída')}</div><p class="muted">${escapeHtml(n.message)}</p><small>${escapeHtml(n.target)}</small></button>`).join('')}</div>`)}</section>`;
}

function profileView() {
  pageTitle.textContent = 'Mi perfil';
  pageSubtitle.textContent = 'Consulta y edición de datos personales';
  return `<section class="dashboard-grid stretch">${card('Datos personales', `<div class="list-simple"><div class="list-item"><strong>Nombre</strong><p class="muted">${escapeHtml(currentProfile?.full_name || currentUser.name || 'Usuario')}</p></div><div class="list-item"><strong>Email</strong><p class="muted">${escapeHtml(currentProfile?.email || currentUser.email || '')}</p></div><div class="list-item"><strong>Rol</strong><p class="muted">${escapeHtml(roleLabels[roleKey])}</p></div><div class="list-item"><strong>WhatsApp</strong><p class="muted">+54 9 11 5555 1111</p></div></div>`)}${card('Editar perfil', `<form class="form-grid"><label><span>Nombre completo</span><input value="${escapeHtml(currentProfile?.full_name || currentUser.name || '')}" /></label><label><span>DNI</span><input value="30111222" /></label><label><span>Fecha de nacimiento</span><input type="date" value="1985-03-20" /></label><label><span>WhatsApp</span><input value="+54 9 11 5555 1111" /></label><label class="full-span"><span>Foto de perfil</span><button type="button" class="btn btn-secondary" id="changeAvatarFromProfile">Cambiar imagen</button></label><button class="btn btn-primary" type="button">Guardar cambios</button></form>`)}</section>`;
}

function settingsView() {
  pageTitle.textContent = 'Configuraciones';
  pageSubtitle.textContent = 'Branding, parámetros globales y comportamiento del sistema';
  return `<section class="dashboard-grid stretch">${card('Sistema', `<form class="form-grid"><label><span>Nombre institucional</span><input value="Instituto San Miguel" /></label><label><span>Logo institucional</span><input type="file" accept="image/*" /></label><label><span>Color principal</span><input type="color" value="#5568ff" /></label><label><span>Zona horaria</span><select><option>America/Argentina/Buenos_Aires</option></select></label><button class="btn btn-primary" type="button">Guardar configuración</button></form>`)}${card('Ajustes activos', `<div class="list-simple"><div class="list-item"><strong>Temas mejorados</strong><p class="muted">Modo oscuro y claro modernizados, con mayor contraste de iconos y superficies.</p></div><div class="list-item"><strong>CSV por módulo</strong><p class="muted">Importación y exportación contemplada en usuarios, equipos, inventario, cursos y biblioteca.</p></div><div class="list-item"><strong>Alertas</strong><p class="muted">Interacciones UI mediante SweetAlert2.</p></div></div>`)}</section>`;
}

const views = { dashboard: dashboardView, users: usersView, roles: rolesView, team: teamView, inventory: inventoryView, courses: coursesView, library: libraryView, notifications: notificationsView, profile: profileView, settings: settingsView };

function mountCharts() {
  charts.forEach(chart => chart.destroy());
  charts = [];
  const add = (id, config) => {
    const ctx = document.getElementById(id);
    if (ctx) charts.push(new Chart(ctx, config));
  };
  add('dashboardBarChart', { type: 'bar', data: { labels: ['Usuarios','Equipos','Inventario','Préstamos'], datasets: [{ label: 'Totales', data: [4,3,5,3] }] }, options: { responsive: true, plugins: { legend: { display: false } } } });
  add('dashboardDonutChart', { type: 'doughnut', data: { labels: ['Campus','Inventario','Biblioteca'], datasets: [{ data: [38,42,20] }] }, options: { responsive: true } });
  add('dashboardLineChart', { type: 'line', data: { labels: ['Ene','Feb','Mar','Abr','May','Jun'], datasets: [{ label: 'Movimientos', data: [8,12,10,15,18,14], tension: 0.35 }] }, options: { responsive: true } });
  add('usersRoleChart', { type: 'pie', data: { labels: ['Administrador','Docente','Alumno'], datasets: [{ data: [1,2,1] }] }, options: { responsive: true } });
  add('usersStatusChart', { type: 'bar', data: { labels: ['Activo','Pendiente'], datasets: [{ label: 'Usuarios', data: [3,1] }] }, options: { responsive: true, plugins: { legend: { display: false } } } });
  add('teamsChart', { type: 'bar', data: { labels: ['5°A','6°C','Mixtos'], datasets: [{ label: 'Equipos', data: [1,1,1] }] }, options: { responsive: true, plugins: { legend: { display: false } } } });
  add('inventoryBarChart', { type: 'bar', data: { labels: ['Nuevo','En préstamo','Dañado'], datasets: [{ label: 'Activos', data: [2,1,1] }] }, options: { responsive: true, plugins: { legend: { display: false } } } });
  add('inventoryLineChart', { type: 'line', data: { labels: ['Lun','Mar','Mié','Jue','Vie'], datasets: [{ label: 'Salidas', data: [1,3,2,4,1], tension: 0.35 }, { label: 'Devoluciones', data: [0,1,1,2,3], tension: 0.35 }] }, options: { responsive: true } });
  add('coursesChart', { type: 'bar', data: { labels: demoState.modules.map(m => m.name), datasets: [{ label: 'Progreso', data: demoState.modules.map(m => m.completion) }] }, options: { responsive: true, indexAxis: 'y', plugins: { legend: { display: false } } } });
}

function bindDynamicEvents() {
  document.querySelectorAll('[data-export]').forEach(btn => btn.addEventListener('click', () => {
    const key = btn.dataset.export;
    const map = { users: demoState.users, teams: demoState.teams, inventory: demoState.inventoryCatalog, courses: demoState.modules, library: demoState.library };
    exportToCSV(`ism-${key}.csv`, map[key]);
    sweetInfo('CSV exportado', `Se generó el archivo del módulo ${key}.`);
  }));

  document.querySelectorAll('[data-import]').forEach(input => input.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const rows = parseCSV(text);
    sweetInfo('CSV importado', `Se leyeron ${rows.length} filas para ${input.dataset.import}.`, 'info');
    input.value = '';
  }));

  document.querySelectorAll('[data-role]').forEach(btn => btn.addEventListener('click', () => {
    const user = { ...(JSON.parse(localStorage.getItem('ism_demo_user') || '{}')) };
    user.role = btn.dataset.role;
    user.name = roleLabels[user.role];
    localStorage.setItem('ism_demo_user', JSON.stringify(user));
    roleKey = user.role;
    setHeaderUser();
    renderRoute();
  }));

  document.querySelectorAll('.notification-detail').forEach(btn => btn.addEventListener('click', () => {
    const id = Number(btn.dataset.id);
    selectedNotificationId = id;
    localStorage.setItem('ism_selected_notification', String(id));
    const found = demoState.notifications.find(n => n.id === id);
    if (found) found.unread = false;
    renderRoute();
    updateNotificationPreview();
  }));

  document.getElementById('sendNotificationBtn')?.addEventListener('click', () => sweetInfo('Notificación enviada', 'La notificación fue enviada correctamente.', 'success'));
  document.getElementById('changeAvatarFromProfile')?.addEventListener('click', () => avatarInput.click());
  document.querySelectorAll('.action-btn').forEach(btn => btn.addEventListener('click', genericActionHandler));
}

function renderRoute() {
  const route = location.hash.replace('#','') || 'dashboard';
  const view = views[route] || dashboardView;
  appContent.innerHTML = view();
  renderNav();
  bindDynamicEvents();
  mountCharts();
}

function applyTheme(theme) {
  document.body.classList.toggle('light', theme === 'light');
  localStorage.setItem('ism_theme', theme);
}

async function initProfile() {
  if (window.sb?.enabled) {
    try {
      const profile = await window.sb.fetchProfile();
      if (profile) {
        currentProfile = profile;
        roleKey = profile.roles?.code || roleKey;
      }
    } catch (error) {
      console.warn(error);
    }
  }
  setHeaderUser();
}

function logout() {
  localStorage.removeItem('ism_demo_user');
  window.location.href = './index.html';
}

setHeaderIcons();
document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  if (window.innerWidth <= 900) appShell.classList.toggle('sidebar-open');
  else appShell.classList.toggle('collapsed');
});
themeToggle?.addEventListener('click', () => applyTheme(document.body.classList.contains('light') ? 'dark' : 'light'));
document.getElementById('fullscreenBtn')?.addEventListener('click', async () => {
  if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
  else await document.exitFullscreen();
});
document.getElementById('profileNameBtn')?.addEventListener('click', () => location.hash = '#profile');
document.getElementById('avatarUploadBtn')?.addEventListener('click', () => avatarInput.click());
avatarInput?.addEventListener('change', (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    localStorage.setItem('ism_avatar_url', reader.result);
    setHeaderUser();
    sweetInfo('Foto actualizada', 'La imagen de perfil fue actualizada.');
  };
  reader.readAsDataURL(file);
});
document.getElementById('notificationsBtn')?.addEventListener('click', (e) => {
  e.stopPropagation();
  notificationsWrapper.classList.toggle('open');
});
document.getElementById('logoutHeaderBtn')?.addEventListener('click', logout);
document.addEventListener('click', (e) => {
  if (!notificationsWrapper.contains(e.target)) notificationsWrapper.classList.remove('open');
});
window.addEventListener('hashchange', renderRoute);
window.addEventListener('resize', () => { if (window.innerWidth > 900) appShell.classList.remove('sidebar-open'); });
document.body.classList.toggle('light', (localStorage.getItem('ism_theme') || 'dark') === 'light');
updateNotificationPreview();
initProfile().finally(renderRoute);
