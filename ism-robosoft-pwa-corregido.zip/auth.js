const authMessage = document.getElementById('authMessage');

const demoUsers = {
  administrator: {
    name: 'Administrador General',
    email: 'admin@ism.edu.ar',
    role: 'administrator',
    avatar_url: './assets/avatar-default.svg',
  },
  teacher: {
    name: 'María López',
    email: 'mlopez@ism.edu.ar',
    role: 'teacher',
    avatar_url: './assets/avatar-default.svg',
  },
  student: {
    name: 'Thiago Benjamín Luna',
    email: 'thiago.luna@ism.edu.ar',
    role: 'student',
    avatar_url: './assets/avatar-default.svg',
  }
};

function goDemo(role = 'administrator', customEmail = '') {
  const user = { ...demoUsers[role] };
  if (customEmail) user.email = customEmail;
  localStorage.setItem('ism_demo_user', JSON.stringify(user));
  window.location.href = './app.html';
}

document.getElementById('demoAccessBtn')?.addEventListener('click', () => goDemo('administrator'));
document.getElementById('demoTeacherBtn')?.addEventListener('click', () => goDemo('teacher'));
document.getElementById('demoStudentBtn')?.addEventListener('click', () => goDemo('student'));

document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  authMessage.textContent = 'Validando acceso...';

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  try {
    if (!window.sb.enabled) {
      let role = 'administrator';
      if (email.includes('docente') || email.includes('mlopez')) role = 'teacher';
      if (email.includes('alumno') || email.includes('thiago')) role = 'student';
      goDemo(role, email || demoUsers[role].email);
      return;
    }

    const { error } = await window.sb.signIn(email, password);
    if (error) throw error;
    window.location.href = './app.html';
  } catch (error) {
    authMessage.textContent = error.message || 'No se pudo iniciar sesión.';
  }
});
