const demoUser = {
  name: 'Admin General',
  email: 'admin@ism.edu.ar',
  role: 'administrator',
  avatar_url: './assets/avatar-default.svg',
};

const authMessage = document.getElementById('authMessage');

document.getElementById('demoAccessBtn')?.addEventListener('click', () => {
  localStorage.setItem('ism_demo_user', JSON.stringify(demoUser));
  window.location.href = './app.html';
});

document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  authMessage.textContent = 'Validando acceso...';

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  try {
    if (!window.sb.enabled) {
      localStorage.setItem('ism_demo_user', JSON.stringify({ ...demoUser, email }));
      window.location.href = './app.html';
      return;
    }

    const { error } = await window.sb.signIn(email, password);
    if (error) throw error;
    window.location.href = './app.html';
  } catch (error) {
    authMessage.textContent = error.message || 'No se pudo iniciar sesión.';
  }
});
