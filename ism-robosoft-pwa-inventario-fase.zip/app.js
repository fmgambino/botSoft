const icons = {
  dashboard: `<svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10Zm10 8h8V11h-8v10ZM3 21h8v-6H3v6Zm10-10h8V3h-8v8Z"></path></svg>`,
  users: `<svg viewBox="0 0 24 24"><path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4ZM8 12a3 3 0 1 0-3-3 3 3 0 0 0 3 3Zm8 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4ZM8 14c-.29 0-.62.02-.97.05C5.7 14.16 2 14.82 2 17v2h4v-1c0-1.46.8-2.68 2.29-3.64A9.79 9.79 0 0 0 8 14Z"></path></svg>`,
  roles: `<svg viewBox="0 0 24 24"><path d="m12 1 9 4v6c0 5.55-3.84 10.74-9 12-5.16-1.26-9-6.45-9-12V5l9-4Zm0 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm0 6c-1.83 0-3.8.93-4 2v1h8v-1c-.2-1.07-2.17-2-4-2Z"></path></svg>`,
  team: `<svg viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.79 2.99-4S17.66 3 16 3s-3 1.79-3 4 1.34 4 3 4Zm-8 0c1.66 0 2.99-1.79 2.99-4S9.66 3 8 3 5 4.79 5 7s1.34 4 3 4Zm0 2c-2.33 0-7 1.17-7 3.5V20h14v-3.5C15 14.17 10.33 13 8 13Zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.95 1.97 3.45V20h6v-3.5c0-2.33-4.67-3.5-7-3.5Z"></path></svg>`,
  inventory: `<svg viewBox="0 0 24 24"><path d="M21 16V8l-9-5-9 5v8l9 5 9-5Zm-9 2.7-6-3.33V9.3l6 3.33 6-3.33v6.07l-6 3.33Zm0-8.37L6.04 7 12 3.7 17.96 7 12 10.33Z"></path></svg>`,
  courses: `<svg viewBox="0 0 24 24"><path d="M12 3 1 9l11 6 9-4.91V17h2V9L12 3Zm-7 9.18V17l7 4 7-4v-4.82l-7 3.82-7-3.82Z"></path></svg>`,
  library: `<svg viewBox="0 0 24 24"><path d="M18 2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10v-2H8V4h10V2Zm-3 4h5a1 1 0 0 1 1 1v15l-3-2-3 2V7a1 1 0 0 1 1-1Z"></path></svg>`,
  notifications: `<svg viewBox="0 0 24 24"><path d="M12 22a2.5 2.5 0 0 0 2.45-2h-4.9A2.5 2.5 0 0 0 12 22Zm7-6V11a7 7 0 1 0-14 0v5L3 18v1h18v-1l-2-2Z"></path></svg>`,
  profile: `<svg viewBox="0 0 24 24"><path d="M12 12a5 5 0 1 0-5-5 5 5 0 0 0 5 5Zm0 2c-4.42 0-8 1.79-8 4v2h16v-2c0-2.21-3.58-4-8-4Z"></path></svg>`,
  settings: `<svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.6-.22l-2.39.96a7.16 7.16 0 0 0-1.63-.94l-.36-2.54a.49.49 0 0 0-.49-.42h-3.84a.49.49 0 0 0-.49.42l-.36 2.54c-.58.22-1.12.53-1.63.94l-2.39-.96a.5.5 0 0 0-.6.22L2.71 8.84a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94L2.83 14.52a.5.5 0 0 0-.12.64l1.92 3.32c.13.22.39.31.6.22l2.39-.96c.51.41 1.05.72 1.63.94l.36 2.54c.05.24.25.42.49.42h3.84c.24 0 .44-.18.49-.42l.36-2.54c.58-.22 1.12-.53 1.63-.94l2.39.96c.22.09.47 0 .6-.22l1.92-3.32a.5.5 0 0 0-.12-.64l-2.03-1.58ZM12 15.5A3.5 3.5 0 1 1 12 8a3.5 3.5 0 0 1 0 7.5Z"></path></svg>`,
  logout: `<svg viewBox="0 0 24 24"><path d="M10 17v-3H3v-4h7V7l5 5-5 5Zm4-14h5a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5v-2h5V5h-5V3Z"></path></svg>`,
  eye: `<svg viewBox="0 0 24 24"><path d="M12 5c5.05 0 9.27 3.11 11 7-1.73 3.89-5.95 7-11 7S2.73 15.89 1 12c1.73-3.89 5.95-7 11-7Zm0 2C8.36 7 5.17 9.06 3.33 12 5.17 14.94 8.36 17 12 17s6.83-2.06 8.67-5C18.83 9.06 15.64 7 12 7Zm0 2.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"></path></svg>`,
  edit: `<svg viewBox="0 0 24 24"><path d="m3 17.25 9.81-9.81 3.75 3.75L6.75 21H3v-3.75ZM14.87 5.38l1.77-1.77a1.5 1.5 0 0 1 2.12 0l1.63 1.63a1.5 1.5 0 0 1 0 2.12l-1.77 1.77-3.75-3.75Z"></path></svg>`,
  trash: `<svg viewBox="0 0 24 24"><path d="M6 7h12l-1 14H7L6 7Zm3-4h6l1 2h4v2H4V5h4l1-2Z"></path></svg>`,
  barcode: `<svg viewBox="0 0 24 24"><path d="M4 5h1v14H4V5Zm3 0h2v14H7V5Zm4 0h1v14h-1V5Zm3 0h3v14h-3V5Zm5 0h1v14h-1V5Z"></path></svg>`
};

const demoState = {
  notifications: [
    { id: 1, title: 'Préstamo vencido', message: 'El kit AR000311 debía devolverse hoy a las 16:00.', unread: true },
    { id: 2, title: 'Ingreso de inventario', message: 'Se registraron 6 sensores ultrasónicos nuevos.', unread: true },
    { id: 3, title: 'Módulo actualizado', message: 'Electrónica aplicada ya tiene evaluativo publicado.', unread: false }
  ],
  users: [
    { full_name: 'Fernando Gambino', role: 'Administrador', email: 'fgambino@ism.edu.ar', whatsapp: '+54 9 11 5555 1111', dni: '30111222', status: 'Activo' },
    { full_name: 'María López', role: 'Docente', email: 'mlopez@ism.edu.ar', whatsapp: '+54 9 11 4444 2222', dni: '28999888', status: 'Activo' },
    { full_name: 'Thiago Benjamín Luna', role: 'Alumno', email: 'thiago.luna@ism.edu.ar', whatsapp: '+54 9 11 3333 1111', dni: '49442589', status: 'Pendiente' }
  ],
  equipment: [
    { name: 'RoboAlpha', leader: 'Thiago Luna', teacher: 'María López', members: 4, course: '6°C', status: 'Activo' },
    { name: 'MechBots', leader: 'Tomás Cáceres', teacher: 'María López', members: 5, course: '5°A', status: 'Activo' }
  ],
  modules: [
    { name: 'Introducción a la robótica', lessons: 5, tasks: 3, evaluative: 'Sí', audience: 'Alumnos 1er tramo' },
    { name: 'Electrónica aplicada', lessons: 7, tasks: 4, evaluative: 'Sí', audience: 'Alumnos avanzados' }
  ],
  library: [
    { title: 'Manual de Arduino', type: 'PDF', access: 'Docentes y Alumnos' },
    { title: 'Reglamento de laboratorio', type: 'PDF', access: 'Todos' },
    { title: 'Catálogo de sensores 2026', type: 'Drive / Link', access: 'Administradores' }
  ],
  inventoryCatalog: [
    { asset_code: 'AR000322', barcode: '8435439883658', description: 'Kit Prog. de las Cosas', brand: 'SetVeintiUno', category: 'Kit de Robótica', supplier: 'BQ Educación', serial: 'SVU-KIT-322', stock_type: 'serializado', status: 'USADO, COMPLETO', location: 'Armario A1', assigned_to: 'Disponible', due_back: '—' },
    { asset_code: 'AR000311', barcode: '9435339883658', description: 'Kit Prog. de las Cosas', brand: 'SetVeintiUno', category: 'Kit de Robótica', supplier: 'BQ Educación', serial: 'SVU-KIT-311', stock_type: 'serializado', status: 'USADO, DAÑADO, FALTA PIEZAS', location: 'Mesa técnica', assigned_to: 'Taller de revisión', due_back: '—' },
    { asset_code: 'AR000362', barcode: '8435439883658', description: 'Kit Prog. de las Cosas', brand: 'SetVeintiUno', category: 'Kit de Robótica', supplier: 'BQ Educación', serial: 'SVU-KIT-362', stock_type: 'serializado', status: 'NUEVO', location: 'Depósito', assigned_to: 'Disponible', due_back: '—' },
    { asset_code: 'SM-USB-001', barcode: 'ISMROB-USB-000001', description: 'Cable USB para kit', brand: 'RobotGroup', category: 'Componentes', supplier: 'ROBOT-GROUP', serial: '', stock_type: 'consumible', status: 'NUEVO', location: 'Gaveta C4', assigned_to: 'Stock', due_back: '—' },
    { asset_code: 'SEN-HCSR04-02', barcode: 'ISMROB-SEN-000002', description: 'Sensor ultrasónico HC-SR04', brand: 'RobotGroup', category: 'Componentes', supplier: 'ROBOT-GROUP', serial: 'HCSR04-7781', stock_type: 'serializado', status: 'EN PRESTAMO', location: 'Aula 6°C', assigned_to: 'Prof. María López', due_back: '18/04/2026 12:00' }
  ],
  inventoryLoans: [
    { code: 'PREST-00021', asset_code: 'SEN-HCSR04-02', item: 'Sensor ultrasónico HC-SR04', requester: 'Prof. María López', team: 'RoboAlpha', requested_at: '14/04/2026 08:10', status_out: 'Operativo / completo', status_in: 'Pendiente', returned_at: '—', due_at: '18/04/2026 12:00' },
    { code: 'PREST-00022', asset_code: 'AR000322', item: 'Kit Prog. de las Cosas', requester: 'Tomás Cáceres', team: 'MechBots', requested_at: '12/04/2026 10:45', status_out: 'Usado / completo', status_in: 'Usado / completo', returned_at: '13/04/2026 14:20', due_at: '13/04/2026 12:00' }
  ],
  inventoryMovements: [
    { at: '14/04/2026 08:10', type: 'Préstamo', barcode: 'ISMROB-SEN-000002', product: 'Sensor ultrasónico HC-SR04', lot: '—', qty: 1, note: 'Entrega a docente para clase de 6°C' },
    { at: '14/04/2026 17:15', type: 'Salida interna', barcode: 'ISMROB-USB-000001', product: 'Cable USB para kit', lot: 'LOTE-USB-26', qty: 2, note: 'Reposición de laboratorio' },
    { at: '13/04/2026 14:20', type: 'Devolución', barcode: '8435439883658', product: 'Kit Prog. de las Cosas', lot: '—', qty: 1, note: 'Se recibió completo' }
  ],
  inventoryLocations: [
    { at: '14/04/2026 08:10', barcode: 'ISMROB-SEN-000002', product: 'Sensor ultrasónico HC-SR04', from: 'Depósito', to: 'Aula 6°C', user: 'María López', note: 'Préstamo a clase' },
    { at: '11/04/2026 09:30', barcode: '9435339883658', product: 'Kit Prog. de las Cosas', from: 'Armario A1', to: 'Mesa técnica', user: 'Fernando Gambino', note: 'Control por faltante de piezas' }
  ],
  inventorySuppliers: [
    { id: 'PV-000-0001', name: 'BQ Educación', cuit: '30-71753486-3', active: 'YES' },
    { id: 'PV-000-0002', name: 'ROBOT-GROUP', cuit: '30-71601502-1', active: 'YES' },
    { id: 'PV-000-0003', name: 'ELECTRÓNICA GAMBINO', cuit: '20-34185420-3', active: 'NO' }
  ],
  inventoryCategories: ['Kit de Robótica', 'Libros', 'Herramientas', 'Componentes'],
  inventoryStatuses: ['NUEVO', 'USADO', 'EN REVISION', 'EN REPARACIÓN', 'PARCIAL', 'DAÑADO', 'FALTA PIEZAS', 'COMPLETO', 'FALTA CABLE USB']
};

const navByRole = {
  administrator: [
    ['dashboard', 'Dashboard'], ['users', 'Usuarios'], ['roles', 'Roles y permisos'], ['team', 'Equipos'], ['inventory', 'Inventario'],
    ['courses', 'Campus docente'], ['library', 'Biblioteca digital'], ['notifications', 'Notificaciones'], ['profile', 'Mi perfil'], ['settings', 'Configuraciones']
  ],
  teacher: [
    ['dashboard', 'Dashboard'], ['team', 'Equipos asignados'], ['inventory', 'Inventario'], ['courses', 'Módulos y tareas'], ['library', 'Biblioteca digital'], ['notifications', 'Notificaciones'], ['profile', 'Mi perfil']
  ],
  student: [
    ['dashboard', 'Dashboard'], ['courses', 'Mis módulos'], ['library', 'Biblioteca digital'], ['profile', 'Mi perfil']
  ]
};

const appShell = document.getElementById('appShell');
const navMenu = document.getElementById('navMenu');
const pageTitle = document.getElementById('pageTitle');
const pageSubtitle = document.getElementById('pageSubtitle');
const appContent = document.getElementById('appContent');
const notificationCount = document.getElementById('notificationCount');
const notificationsPreview = document.getElementById('notificationsPreview');
const headerUserName = document.getElementById('headerUserName');
const headerAvatar = document.getElementById('headerAvatar');

let roleKey = localStorage.getItem('ism_demo_role') || 'administrator';
let currentUser = { name: 'Administrador General', email: 'admin@ism.edu.ar' };
let currentProfile = null;

function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function statusPill(value) {
  const t = String(value || '').toLowerCase();
  const cls = t.includes('aprob') || t.includes('activo') || t.includes('dispon') || t.includes('nuevo') || t.includes('completo') || t.includes('yes') ? 'status-approved'
    : t.includes('pend') || t.includes('revision') || t.includes('préstamo') || t.includes('prestamo') || t.includes('bajo') || t.includes('operativo') ? 'status-pending'
    : 'status-rejected';
  return `<span class="status-pill ${cls}">${escapeHtml(value || 'Sin estado')}</span>`;
}

function tableActions() {
  return `<div class="actions"><button class="action-btn" title="Ver">${icons.eye}</button><button class="action-btn" title="Editar">${icons.edit}</button><button class="action-btn" title="Eliminar">${icons.trash}</button></div>`;
}

function card(title, content, extraClass = '') {
  return `<section class="card glass ${extraClass}"><h3>${title}</h3><div class="card-body">${content}</div></section>`;
}

function renderNav() {
  const route = location.hash.replace('#', '') || 'dashboard';
  const items = navByRole[roleKey] || navByRole.administrator;
  navMenu.innerHTML = items.map(([key, label]) => `<a href="#${key}" class="nav-item ${route === key ? 'active' : ''}">${icons[key]}<span>${label}</span></a>`).join('') + `<button class="nav-item" id="logoutBtn" type="button">${icons.logout}<span>Cerrar sesión</span></button>`;
  document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    localStorage.removeItem('ism_session');
    if (window.sb?.enabled) {
      try { await window.sb.signOut(); } catch (_) {}
    }
    location.href = './index.html';
  });
}

function renderNotificationsPreview() {
  const unread = demoState.notifications.filter(n => n.unread);
  notificationCount.textContent = unread.length;
  notificationsPreview.innerHTML = demoState.notifications.map(n => `<div class="list-item"><div class="metric-inline"><strong>${escapeHtml(n.title)}</strong>${statusPill(n.unread ? 'Sin leer' : 'Leída')}</div><p class="muted">${escapeHtml(n.message)}</p></div>`).join('');
}

function setHeaderUser() {
  headerUserName.textContent = currentProfile?.full_name || currentUser.name;
  headerAvatar.src = currentProfile?.avatar_url || './assets/avatar-default.svg';
}

function dashboardView() {
  pageTitle.textContent = 'Dashboard';
  pageSubtitle.textContent = 'Gestión administrativa del Laboratorio de Robótica';
  return `
    <section class="grid-cards">
      ${card('Usuarios', `<div class="kpi">148</div><p class="muted">Administradores, docentes y alumnos activos.</p>`)}
      ${card('Equipos', `<div class="kpi">12</div><p class="muted">Equipos de alumnos asignados a docentes.</p>`)}
      ${card('Inventario', `<div class="kpi">106</div><p class="muted">Registros en catálogo e insumos trazables.</p>`)}
      ${card('Préstamos abiertos', `<div class="kpi">9</div><p class="muted">Con seguimiento y devolución pendiente.</p>`)}
    </section>
    <section class="layout-two">
      ${card('Resumen operativo', `<div class="list-simple"><div class="list-item"><strong>ABM de usuarios</strong><p class="muted">Alta, baja y modificación con roles, permisos y perfiles.</p></div><div class="list-item"><strong>Panel docente</strong><p class="muted">Carga de módulos, lecciones, tareas y evaluativos estilo LearnPress.</p></div><div class="list-item"><strong>Inventario inteligente</strong><p class="muted">Trazabilidad por serie o código de barras, préstamos y devoluciones.</p></div></div>`)}
      ${card('Alertas del día', demoState.notifications.map(n => `<div class="list-item"><div class="metric-inline"><strong>${escapeHtml(n.title)}</strong>${statusPill(n.unread ? 'Sin leer' : 'Leída')}</div><p class="muted">${escapeHtml(n.message)}</p></div>`).join(''))}
    </section>
    <section class="card glass"><div class="section-header"><div><h3>Inventario destacado</h3><p class="muted">Basado en la planilla de control adjunta.</p></div><div class="toolbar"><a href="#inventory" class="btn btn-primary">Abrir módulo</a></div></div><div class="inventory-highlight">${demoState.inventoryCatalog.slice(0, 3).map(item => `<article class="list-item"><div class="metric-inline"><strong>${escapeHtml(item.asset_code)}</strong>${statusPill(item.status)}</div><p>${escapeHtml(item.description)}</p><p class="muted">${escapeHtml(item.category)} · ${escapeHtml(item.location)} · ${escapeHtml(item.assigned_to)}</p></article>`).join('')}</div></section>`;
}

function usersView() {
  pageTitle.textContent = 'Usuarios';
  pageSubtitle.textContent = 'ABM de usuarios con roles, permisos y perfil extendido';
  return `<section class="card glass"><div class="section-header"><div><h3>Usuarios registrados</h3><p class="muted">Campos sugeridos: WhatsApp, fecha de nacimiento, curso/división o materia/título.</p></div><div class="toolbar"><button class="btn btn-primary">Nuevo usuario</button><button class="btn btn-secondary">Importar CSV</button></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Nombre</th><th>Rol</th><th>Email</th><th>WhatsApp</th><th>DNI</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${demoState.users.map(u => `<tr><td><strong>${escapeHtml(u.full_name)}</strong></td><td>${escapeHtml(u.role)}</td><td>${escapeHtml(u.email)}</td><td>${escapeHtml(u.whatsapp)}</td><td>${escapeHtml(u.dni)}</td><td>${statusPill(u.status)}</td><td>${tableActions()}</td></tr>`).join('')}</tbody></table></div></section>`;
}

function rolesView() {
  pageTitle.textContent = 'Roles y permisos';
  pageSubtitle.textContent = 'Los administradores pueden gestionar perfiles, permisos y alcance por módulo';
  return `<section class="layout-two">${card('Roles del sistema', `<div class="list-simple"><div class="list-item"><strong>Administrador</strong><p class="muted">Administra todos los perfiles, configuración global, inventario y notificaciones.</p></div><div class="list-item"><strong>Docente</strong><p class="muted">Gestiona equipos asignados, préstamos, devoluciones y campus docente.</p></div><div class="list-item"><strong>Alumno</strong><p class="muted">Consulta módulos, tareas y recursos permitidos.</p></div></div>`)}${card('Permisos destacados', `<div class="list-simple"><div class="list-item"><strong>inventory.manage</strong><p class="muted">Alta, edición y baja lógica de activos e insumos.</p></div><div class="list-item"><strong>inventory.checkout</strong><p class="muted">Registrar entrega, estado de salida y fecha prevista de devolución.</p></div><div class="list-item"><strong>inventory.return</strong><p class="muted">Registrar devolución, estado de ingreso y observaciones.</p></div></div>`)}</section>`;
}

function teamView() {
  pageTitle.textContent = roleKey === 'teacher' ? 'Equipos asignados' : 'Equipos';
  pageSubtitle.textContent = 'Seguimiento de equipos de alumnos y docente responsable';
  return `<section class="card glass"><div class="section-header"><div><h3>Equipos</h3><p class="muted">Un docente puede administrar uno o varios equipos asignados.</p></div><div class="toolbar"><button class="btn btn-primary">Nuevo equipo</button></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Equipo</th><th>Líder</th><th>Docente</th><th>Integrantes</th><th>Curso</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>${demoState.equipment.map(e => `<tr><td><strong>${escapeHtml(e.name)}</strong></td><td>${escapeHtml(e.leader)}</td><td>${escapeHtml(e.teacher)}</td><td>${escapeHtml(e.members)}</td><td>${escapeHtml(e.course)}</td><td>${statusPill(e.status)}</td><td>${tableActions()}</td></tr>`).join('')}</tbody></table></div></section>`;
}

function inventoryView() {
  pageTitle.textContent = 'Inventario del Laboratorio';
  pageSubtitle.textContent = 'Módulo completo: catálogo, préstamos, devoluciones, trazabilidad y códigos de barras';
  const activos = demoState.inventoryCatalog.length;
  const serializados = demoState.inventoryCatalog.filter(i => i.stock_type === 'serializado').length;
  const prestamosAbiertos = demoState.inventoryLoans.filter(i => i.returned_at === '—').length;
  const bajoRevision = demoState.inventoryCatalog.filter(i => i.status.toLowerCase().includes('dañado') || i.status.toLowerCase().includes('revision')).length;
  return `
    <section class="grid-cards">
      ${card('Activos / insumos', `<div class="kpi">${activos}</div><p class="muted">Catálogo unificado con datos de la planilla y Supabase.</p>`)}
      ${card('Serializados', `<div class="kpi">${serializados}</div><p class="muted">Control individual por número de serie o barcode.</p>`)}
      ${card('Préstamos abiertos', `<div class="kpi">${prestamosAbiertos}</div><p class="muted">Docentes o equipos con seguimiento activo.</p>`)}
      ${card('En revisión', `<div class="kpi">${bajoRevision}</div><p class="muted">Requieren mantenimiento o reposición.</p>`)}
    </section>
    <section class="inventory-layout">${card('Flujo operativo', `<div class="flow-steps"><div class="flow-step"><strong>1. Alta</strong><p class="muted">Cada insumo se registra como activo serializado, por lote o consumible.</p></div><div class="flow-step"><strong>2. Etiquetado</strong><p class="muted">Si no tiene serie, el sistema genera un código de barras interno.</p></div><div class="flow-step"><strong>3. Entrega</strong><p class="muted">Se deja trazado quién lo pidió, estado de salida y fecha prevista.</p></div><div class="flow-step"><strong>4. Devolución</strong><p class="muted">Se registra estado de regreso, fecha y observaciones.</p></div></div>`)}${card('Acciones rápidas', `<div class="toolbar vertical-toolbar"><button class="btn btn-primary">Nuevo activo</button><button class="btn btn-secondary">${icons.barcode} Generar barcode</button><button class="btn btn-secondary">Registrar préstamo</button><button class="btn btn-secondary">Registrar devolución</button><button class="btn btn-secondary">Importar planilla / CSV</button></div>`)}</section>
    <section class="card glass"><div class="section-header"><div><h3>Catálogo trazable</h3><p class="muted">Cada fila representa una unidad o activo controlable. Los consumibles sin serie reciben barcode interno.</p></div><div class="toolbar"><span class="pill-static">Serie / Barcode</span><span class="pill-static">Ubicación</span><span class="pill-static">Responsable actual</span></div></div><div class="table-wrap"><table class="table inventory-table"><thead><tr><th>Código interno</th><th>Barcode</th><th>Descripción</th><th>Marca</th><th>Categoría</th><th>N° Serie</th><th>Tipo</th><th>Estado</th><th>Ubicación</th><th>Responsable</th><th>Próxima devolución</th><th>Acciones</th></tr></thead><tbody>${demoState.inventoryCatalog.map(item => `<tr><td><strong>${escapeHtml(item.asset_code)}</strong></td><td class="barcode-cell"><span>${escapeHtml(item.barcode)}</span><button class="mini-icon" title="Barcode">${icons.barcode}</button></td><td><strong>${escapeHtml(item.description)}</strong><div class="muted small">Proveedor: ${escapeHtml(item.supplier)}</div></td><td>${escapeHtml(item.brand)}</td><td>${escapeHtml(item.category)}</td><td>${escapeHtml(item.serial || 'Generado por sistema')}</td><td>${statusPill(item.stock_type === 'serializado' ? 'Serializado' : 'Consumible')}</td><td>${statusPill(item.status)}</td><td>${escapeHtml(item.location)}</td><td>${escapeHtml(item.assigned_to)}</td><td>${escapeHtml(item.due_back)}</td><td>${tableActions()}</td></tr>`).join('')}</tbody></table></div></section>
    <section class="inventory-layout">${card('Formulario de alta / edición', `<form class="form-grid inventory-form"><label><span>Tipo de registro</span><select><option>Activo serializado</option><option>Consumible</option><option>Lote</option></select></label><label><span>Descripción</span><input placeholder="Ej. Sensor ultrasónico HC-SR04" /></label><label><span>Proveedor / Marca</span><select>${demoState.inventorySuppliers.map(s => `<option>${s.name}</option>`).join('')}</select></label><label><span>Categoría</span><select>${demoState.inventoryCategories.map(c => `<option>${c}</option>`).join('')}</select></label><label><span>Número de serie</span><input placeholder="Opcional" /></label><label><span>Código de barras</span><input placeholder="Autogenerar si no existe" /></label><label><span>Estado inicial</span><select>${demoState.inventoryStatuses.map(s => `<option>${s}</option>`).join('')}</select></label><label><span>Ubicación</span><input placeholder="Armario, aula, depósito..." /></label><label><span>Fecha de ingreso</span><input type="date" /></label><label><span>Fecha de vencimiento</span><input type="date" /></label><label><span>Cantidad</span><input type="number" min="1" value="1" /></label><label><span>Stock mínimo</span><input type="number" min="0" value="0" /></label><label class="full-span"><span>Observaciones</span><textarea rows="4" placeholder="Observaciones del alta o estado del insumo"></textarea></label><div class="toolbar full-span"><button class="btn btn-primary" type="button">Guardar activo</button><button class="btn btn-secondary" type="button">Guardar y generar etiqueta</button></div></form>`)}${card('Política de identificación', `<div class="list-simple"><div class="list-item"><strong>Con número de serie</strong><p class="muted">El barcode se vincula al serial real del fabricante y conserva trazabilidad completa.</p></div><div class="list-item"><strong>Sin número de serie</strong><p class="muted">El sistema genera un barcode interno con prefijo ISMROB y secuencia correlativa.</p></div><div class="list-item"><strong>Consumibles</strong><p class="muted">Se admite manejo por lote, cantidad y vencimiento.</p></div></div><div class="barcode-preview glass"><div class="barcode-lines"></div><strong>ISMROB-USB-000001</strong><p class="muted">Ejemplo de etiqueta autogenerada</p></div>`)}</section>
    <section class="card glass"><div class="section-header"><div><h3>Préstamos y devoluciones</h3><p class="muted">Permite saber quién tiene cada insumo, cuándo lo pidió, en qué estado salió y cómo regresó.</p></div><div class="toolbar"><button class="btn btn-primary">Nuevo préstamo</button><button class="btn btn-secondary">Procesar devolución</button></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Solicitud</th><th>Activo</th><th>Solicitante</th><th>Equipo</th><th>Retiro</th><th>Estado salida</th><th>Devolución prevista</th><th>Estado devolución</th><th>Fecha devolución</th></tr></thead><tbody>${demoState.inventoryLoans.map(loan => `<tr><td><strong>${escapeHtml(loan.code)}</strong></td><td>${escapeHtml(loan.asset_code)}<div class="muted small">${escapeHtml(loan.item)}</div></td><td>${escapeHtml(loan.requester)}</td><td>${escapeHtml(loan.team)}</td><td>${escapeHtml(loan.requested_at)}</td><td>${statusPill(loan.status_out)}</td><td>${escapeHtml(loan.due_at)}</td><td>${statusPill(loan.status_in)}</td><td>${escapeHtml(loan.returned_at)}</td></tr>`).join('')}</tbody></table></div></section>
    <section class="inventory-layout">${card('Bitácora de movimientos', `<div class="table-wrap"><table class="table"><thead><tr><th>Fecha</th><th>Tipo</th><th>Barcode</th><th>Producto</th><th>Lote</th><th>Cant.</th><th>Observación</th></tr></thead><tbody>${demoState.inventoryMovements.map(m => `<tr><td>${escapeHtml(m.at)}</td><td>${statusPill(m.type)}</td><td>${escapeHtml(m.barcode)}</td><td>${escapeHtml(m.product)}</td><td>${escapeHtml(m.lot)}</td><td>${escapeHtml(m.qty)}</td><td>${escapeHtml(m.note)}</td></tr>`).join('')}</tbody></table></div>`)}${card('Historial de ubicaciones', `<div class="table-wrap"><table class="table"><thead><tr><th>Fecha</th><th>Barcode</th><th>Producto</th><th>Ubicación anterior</th><th>Nueva ubicación</th><th>Usuario</th><th>Observación</th></tr></thead><tbody>${demoState.inventoryLocations.map(m => `<tr><td>${escapeHtml(m.at)}</td><td>${escapeHtml(m.barcode)}</td><td>${escapeHtml(m.product)}</td><td>${escapeHtml(m.from)}</td><td>${escapeHtml(m.to)}</td><td>${escapeHtml(m.user)}</td><td>${escapeHtml(m.note)}</td></tr>`).join('')}</tbody></table></div>`)}</section>
    <section class="inventory-layout">${card('Importación desde planilla', `<div class="list-simple"><div class="list-item"><strong>Hojas detectadas</strong><p class="muted">Inventario, Movimientos, Proveedores, Marcas, Categorías, HistorialUbicaciones y Status.</p></div><div class="list-item"><strong>Mapeo sugerido</strong><p class="muted">Código de Barras → barcode, Descripción → description, MARCA → brand, Fecha de Ingreso → received_at, Ubicación → location.</p></div><div class="list-item"><strong>Normalización</strong><p class="muted">Los estados compuestos como “USADO, COMPLETO” se guardan como estado + condición detallada.</p></div></div>`)}${card('Proveedores del sistema', `<div class="table-wrap"><table class="table"><thead><tr><th>ID</th><th>Proveedor</th><th>CUIT</th><th>Activo</th></tr></thead><tbody>${demoState.inventorySuppliers.map(s => `<tr><td>${escapeHtml(s.id)}</td><td>${escapeHtml(s.name)}</td><td>${escapeHtml(s.cuit)}</td><td>${statusPill(s.active)}</td></tr>`).join('')}</tbody></table></div>`)}</section>`;
}

function coursesView() {
  pageTitle.textContent = roleKey === 'student' ? 'Mis módulos' : 'Campus docente';
  pageSubtitle.textContent = 'Módulos, lecciones, tareas y evaluativos estilo LearnPress';
  return `<section class="course-grid">${card('Estructura pedagógica', `<div class="list-simple"><div class="list-item"><strong>Módulos</strong><p class="muted">Agrupan contenidos, lecciones, tareas y evaluaciones.</p></div><div class="list-item"><strong>Lecciones</strong><p class="muted">Texto enriquecido, videos, adjuntos y recursos externos.</p></div><div class="list-item"><strong>Tareas / Evaluativos</strong><p class="muted">Con fecha límite, rúbrica y calificación.</p></div></div>`)}${card('Acciones rápidas', `<div class="toolbar"><button class="btn btn-primary">Nuevo módulo</button><button class="btn btn-secondary">Nueva lección</button><button class="btn btn-secondary">Nuevo evaluativo</button></div>`)}</section><section class="card glass"><div class="table-wrap"><table class="table"><thead><tr><th>Módulo</th><th>Lecciones</th><th>Tareas</th><th>Evaluativo</th><th>Público</th><th>Acciones</th></tr></thead><tbody>${demoState.modules.map(m => `<tr><td><strong>${escapeHtml(m.name)}</strong></td><td>${m.lessons}</td><td>${m.tasks}</td><td>${m.evaluative}</td><td>${escapeHtml(m.audience)}</td><td>${tableActions()}</td></tr>`).join('')}</tbody></table></div></section>`;
}

function libraryView() {
  pageTitle.textContent = 'Biblioteca digital';
  pageSubtitle.textContent = 'Repositorio de manuales, reglamentos y material de estudio';
  return `<section class="card glass"><div class="section-header"><div><h3>Recursos</h3><p class="muted">Subida de archivos, enlaces externos y permisos por rol.</p></div><div class="toolbar"><button class="btn btn-primary">Subir recurso</button></div></div><div class="file-grid">${demoState.library.map(file => `<article class="file-item glass"><strong>${escapeHtml(file.title)}</strong><p class="muted">${escapeHtml(file.type)}</p>${statusPill(file.access)}</article>`).join('')}</div></section>`;
}

function notificationsView() {
  pageTitle.textContent = 'Notificaciones';
  pageSubtitle.textContent = 'Envío masivo, individual, por equipo o múltiple selección';
  return `<section class="layout-two">${card('Enviar notificación', `<form class="form-grid"><label><span>Destino</span><select><option>Todos los usuarios</option><option>Individual</option><option>Equipo</option><option>Selección múltiple</option></select></label><label><span>Título</span><input placeholder="Asunto de la notificación" /></label><label><span>Mensaje</span><textarea rows="5" placeholder="Escribí el contenido"></textarea></label><button class="btn btn-primary" type="button">Enviar</button></form>`)}${card('Bandeja', demoState.notifications.map(n => `<div class="list-item"><div class="metric-inline"><strong>${escapeHtml(n.title)}</strong>${statusPill(n.unread ? 'Sin leer' : 'Leída')}</div><p class="muted">${escapeHtml(n.message)}</p></div>`).join(''))}</section>`;
}

function profileView() {
  pageTitle.textContent = 'Mi perfil';
  pageSubtitle.textContent = 'Consulta y edición de datos personales';
  return `<section class="profile-layout">${card('Datos personales', `<div class="list-simple"><div class="list-item"><strong>Nombre</strong><p class="muted">${escapeHtml(currentProfile?.full_name || currentUser.name)}</p></div><div class="list-item"><strong>Email</strong><p class="muted">${escapeHtml(currentProfile?.email || currentUser.email)}</p></div><div class="list-item"><strong>Rol</strong><p class="muted">${escapeHtml(roleKey)}</p></div><div class="list-item"><strong>WhatsApp</strong><p class="muted">+54 9 11 5555 1111</p></div></div>`)}${card('Editar perfil', `<form class="form-grid"><label><span>Nombre completo</span><input value="${escapeHtml(currentProfile?.full_name || currentUser.name)}" /></label><label><span>DNI</span><input value="30111222" /></label><label><span>Fecha de nacimiento</span><input type="date" value="1985-03-20" /></label><label><span>WhatsApp</span><input value="+54 9 11 5555 1111" /></label><label><span>Foto de perfil</span><input type="file" accept="image/*" /></label><button class="btn btn-primary" type="button">Guardar cambios</button></form>`)}</section>`;
}

function settingsView() {
  pageTitle.textContent = 'Configuraciones';
  pageSubtitle.textContent = 'Personalización del sistema, branding y parámetros globales';
  return `<section class="settings-layout">${card('Sistema', `<form class="form-grid"><label><span>Nombre institucional</span><input value="Instituto San Miguel" /></label><label><span>Logo institucional</span><input type="file" accept="image/*" /></label><label><span>Color principal</span><input type="color" value="#78a6ff" /></label><label><span>Zona horaria</span><select><option>America/Argentina/Buenos_Aires</option></select></label><button class="btn btn-primary" type="button">Guardar configuración</button></form>`)}${card('Parámetros funcionales', `<div class="list-simple"><div class="list-item"><strong>Registro de alumnos</strong><p class="muted">Campos: curso, división, DNI, WhatsApp y fecha de nacimiento.</p></div><div class="list-item"><strong>Registro docente</strong><p class="muted">Campos: materia, título, DNI, fecha de nacimiento y WhatsApp.</p></div><div class="list-item"><strong>Inventario</strong><p class="muted">Alta de activos, préstamos, devoluciones, mantenimiento, barcodes y stock mínimo.</p></div></div>`)}</section>`;
}

const views = { dashboard: dashboardView, users: usersView, roles: rolesView, team: teamView, inventory: inventoryView, courses: coursesView, library: libraryView, notifications: notificationsView, profile: profileView, settings: settingsView };

function renderRoute() {
  const route = location.hash.replace('#', '') || 'dashboard';
  const view = views[route] || dashboardView;
  appContent.innerHTML = view();
  renderNav();
}

function applyTheme(theme) {
  document.body.classList.toggle('light', theme === 'light');
  localStorage.setItem('ism_theme', theme);
}

async function initProfile() {
  if (window.sb?.enabled) {
    try {
      const profile = await window.sb.fetchProfile();
      if (profile) {
        currentProfile = profile;
        roleKey = profile.roles?.code || 'administrator';
      }
    } catch (e) {
      console.warn('No se pudo cargar el perfil', e);
    }
  }
  setHeaderUser();
}

document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  if (window.innerWidth <= 900) appShell.classList.toggle('sidebar-open');
  else appShell.classList.toggle('collapsed');
});
document.getElementById('themeToggle')?.addEventListener('click', () => applyTheme(document.body.classList.contains('light') ? 'dark' : 'light'));
document.getElementById('fullscreenBtn')?.addEventListener('click', async () => { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); });
document.getElementById('profileQuickBtn')?.addEventListener('click', () => location.hash = 'profile');
document.getElementById('notificationsBtn')?.addEventListener('click', () => location.hash = 'notifications');
window.addEventListener('hashchange', renderRoute);
window.addEventListener('resize', () => { if (window.innerWidth > 900) appShell.classList.remove('sidebar-open'); });
applyTheme(localStorage.getItem('ism_theme') || 'dark');
renderNotificationsPreview();
initProfile().finally(renderRoute);
